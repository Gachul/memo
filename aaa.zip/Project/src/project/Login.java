package project;

import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.*;

import java.util.List;
import java.util.ArrayList;

public class Login extends JFrame implements ActionListener {
	private JFrame f;
	private JPanel p;
	private JLabel mainLgL;
	private JButton loginBtn, backBtn, joinBtn, noMemJoinBtn, noMemLgBtn, homeBtn;
	private JTextField idF;
	private JPasswordField pwF;
	private JLabel idL;
	private JLabel pwL;
	private static final String DB_URL = "jdbc:mysql://127.0.0.1:3306/reservation";
	private static final String USERNAME = "manager01";
	private static final String PASSWORD = "password01";
	private final static String adminId = "Admin";
	private final static String adminPw = "admin1q2w3e4r@";
	
	public String save_tel;
	
	Connection con = null;
	PreparedStatement ps = null;
	ResultSet rs = null;

	public Login() {
		// ������
		f = new JFrame();
		f.setTitle("�װ��� ���� �ý��� - �α���");
		f.setBounds(100, 100, 800, 600);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.getContentPane().setLayout(null);
		f.setResizable(false);
		f.setLocationRelativeTo(null);
		f.setVisible(true);

		// �г�
		p = new JPanel();
		p.setBounds(0, 0, 794, 571);
		f.getContentPane().add(p);
		p.setLayout(null);

		// ����
		mainLgL = new JLabel("MEMBER LOGIN");
		mainLgL.setFont(new Font("����", Font.BOLD, 42));
		mainLgL.setBounds(187, 111, 336, 67);
		p.add(mainLgL);

		// ���̵�
		idL = new JLabel("ID : ");
		idL.setFont(new Font("���ʷҵ���", Font.BOLD, 18));
		idL.setBounds(204, 211, 75, 48);
		idL.setHorizontalAlignment(SwingConstants.CENTER);
		p.add(idL);
		idF = new JTextField();
		idF.setBounds(291, 211, 195, 48);
		idF.setColumns(10);
		p.add(idF);

		// ��й�ȣ
		pwL = new JLabel("PW : ");
		pwL.setFont(new Font("���ʷҵ���", Font.PLAIN, 18));
		pwL.setBounds(204, 281, 75, 48);
		pwL.setHorizontalAlignment(SwingConstants.CENTER);
		p.add(pwL);
		pwF = new JPasswordField();
		pwF.setColumns(12);
		pwF.setBounds(291, 282, 195, 48);
		p.add(pwF);

		// ��ư
		loginBtn = new JButton("�α���");
		loginBtn.setBounds(511, 211, 122, 118);
		loginBtn.setFont(new Font("�Ȼ��2006����", Font.BOLD, 25));
		p.add(loginBtn);

		joinBtn = new JButton("ȸ������");
		joinBtn.setBounds(204, 358, 122, 35);
		p.add(joinBtn);

		noMemJoinBtn = new JButton("��ȸ�� ����");
		noMemJoinBtn.setBounds(360, 358, 122, 35);
		p.add(noMemJoinBtn);

		noMemLgBtn = new JButton("��ȸ�� �α���");
		noMemLgBtn.setBounds(511, 358, 122, 35);
		p.add(noMemLgBtn);

		backBtn = new JButton("<");
		backBtn.setBounds(26, 500, 41, 39);
		p.add(backBtn);

		homeBtn = new JButton("");
		homeBtn.setSelectedIcon(new ImageIcon("C:\\Users\\user\\Documents\\JAVA\\Workspace\\project\\image\\homeBtn.png"));
		homeBtn.setIcon(new ImageIcon("C:\\Users\\user\\Documents\\JAVA\\Workspace\\project\\image\\homeBtn.png"));
		homeBtn.setBounds(729, 20, 41, 39);
		p.add(homeBtn);

		// ������
		loginBtn.addActionListener(this);
		joinBtn.addActionListener(this);
		noMemJoinBtn.addActionListener(this);
		noMemLgBtn.addActionListener(this);
		homeBtn.addActionListener(this);
		backBtn.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == loginBtn) {
			login();
		} else if (e.getSource() == joinBtn) {
			new Join();
			f.dispose();
		} else if (e.getSource() == noMemJoinBtn) {
			new Non_MemberJoin();
			f.dispose();
		} else if (e.getSource() == noMemLgBtn) {
			new Non_MemberLogin();
			f.dispose();
		} else if (e.getSource() == backBtn) {
			new MainUI();
			f.dispose();
		} else if (e.getSource() == homeBtn) {
			new MainUI();
			f.dispose();
		}
	}

	// �α���
	public void login() {
		String sqlLogin = "SELECT userTel FROM memberTBL WHERE userId = ? and userPw = ?";

		if (idF.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "���̵� �Է��ϼ���");
			return;
		} else if (pwF.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "��й�ȣ�� �Է��ϼ���");
			return;
		} else if (idF.getText().equals(adminId) && pwF.getText().equals(adminPw)) {
			JOptionPane.showMessageDialog(null, "������ �α��� ����");
			new Admin();
			f.dispose();
			return;
		}

		try {
			MemberDAO dao = new MemberDAO();
			dao.DBConnection();
			con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
			ps = con.prepareStatement(sqlLogin);
			ps.setString(1, idF.getText());
			ps.setString(2, pwF.getText());
			rs = ps.executeQuery();

			if (rs.next()) {
				save_tel = rs.getString(1);
				Save_tel stl = new Save_tel();
				stl.s_tel(save_tel);
				JOptionPane.showMessageDialog(null, "�α��� �Ϸ�");
				new ReserveMainP();
				f.dispose();
				
			} else
				JOptionPane.showMessageDialog(null, "���̵�/��й�ȣ�� Ʋ�Ƚ��ϴ�");
		} catch (Exception e) {
			System.out.println("�α��� ����");
		}
	}
}