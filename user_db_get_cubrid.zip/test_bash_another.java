import cubrid.jdbc.driver.*;
import cubrid.sql.*;
import java.sql.*;
import java.util.Base64;
import java.util.Base64.Encoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class test_bash_another
{
	
	public static byte[] sha256(String msg) throws NoSuchAlgorithmException {
		
	    MessageDigest md = MessageDigest.getInstance("SHA-256");
	    md.update(msg.getBytes());
	    
	    return md.digest();
	}

	public static void main(String[] args) throws Exception{
		// ������ ���� �Է�
		String auth_sign = "01";
		
		String url= "jdbc:cubrid:192.168.255.78:33000:entdb:::";
		String user = "fmxuser";
		String passwd = "fmxuser!2";

		String req_id = args[0];
		String req_pass = args[1];
		
		Encoder encoder = Base64.getEncoder();
		byte[] to_sha_pw = sha256(req_pass);
		
		StringBuilder str_builder = new StringBuilder();
		for (byte b : to_sha_pw) {str_builder.append(String.format("%02x", b));}
		String sha_pw = str_builder.toString();
		
		byte[] b64_bytes = encoder.encode(sha_pw.toUpperCase().getBytes());
		String enc_pw = new String(b64_bytes);
		
		// ���� �ۼ�
		String sql = "SELECT demo_users from demo_users where username = \'" + req_id + "\'";
		// ã�� column �� ���
		String[] attr = { "password" } ;


		// ����� ���� ����
		Connection my_db = null;
		// statement�� mysql�� cursor ����
		Statement stmt = null;
		CUBRIDResultSet rs = null;

		try {
			Class.forName("cubrid.jdbc.driver.CUBRIDDriver");
		} catch (ClassNotFoundException e) {
			throw new IllegalStateException("Unable to load Cubrid driver", e);
		}

		try {
			// db ���� �κ�
			my_db = DriverManager.getConnection(url, user, passwd);
			stmt = my_db.createStatement();
			rs = (CUBRIDResultSet)stmt.executeQuery(sql);

			// �� ���
			CUBRIDResultSet rsoid = null;

			while (rs.next()) {
				CUBRIDOID oid = rs.getOID(1);
				rsoid = (CUBRIDResultSet)oid.getValues(attr);

				while (rsoid.next()) {
					Object auth_ob_pass = rsoid.getObject(1);
					String auth_pass = String.valueOf(auth_ob_pass);
					auth_pass = auth_pass.replace("\n", "");

					if( enc_pw.equals(auth_pass)) {
						auth_sign = "00";
					}
				}
				if(auth_sign == "00") {
					break;
				}
			}
			my_db.commit();

		} catch(CUBRIDException e) {
			e.printStackTrace();

		} catch(SQLException ex) {
			ex.printStackTrace();

		} finally {
			if(rs != null) try { rs.close(); } catch(SQLException e) {}
			if(stmt != null) try { stmt.close(); } catch(SQLException e) {}
			if(my_db != null) try { my_db.close(); } catch(SQLException e) {}
		}
		System.out.print(auth_sign);
	}
}