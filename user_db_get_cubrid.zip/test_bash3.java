import cubrid.jdbc.driver.*;
import cubrid.sql.*;
import java.sql.*;

public class test_bash3
{

	public static void main(String[] args) {
		String auth_sign = "01";
		
		String url= "jdbc:cubrid:192.168.255.78:30003:insadb:::";
		String user = "fmxuser";
		String passwd = "fmxuser!2";
	
		String sql = "SELECT wifi_user from wifi_user";
		
		String[] attr = { "id", "user_name" };

		// ����� ���� ����
		Connection my_db = null;
		Statement stmt = null;
		CUBRIDResultSet rs = null;

		try {
			Class.forName("cubrid.jdbc.driver.CUBRIDDriver");
		} catch (ClassNotFoundException e) {
			throw new IllegalStateException("Unable to load Cubrid driver", e);
		}

		try {
			// db ���� �κ�
			my_db = DriverManager.getConnection(url, user, passwd);
			stmt = my_db.createStatement();
			
			//String conn_sql = "update wifi_user set id = NULL where id = NULL";
			//stmt.executeUpdate(conn_sql);
			
			rs = (CUBRIDResultSet)stmt.executeQuery(sql);
			
			CUBRIDResultSet rsoid = null;
			
			

			while (rs.next()) {
				CUBRIDOID oid = rs.getOID(1);
				rsoid = (CUBRIDResultSet)oid.getValues(attr);
				while (rsoid.next()) {
					Object auth_ob_user = rsoid.getObject(1);
					String auth_user = String.valueOf(auth_ob_user);
					Object auth_ob_pass = rsoid.getObject(2);
					String auth_pass = String.valueOf(auth_ob_pass);
//					Object auth_ob_real = rsoid.getObject(3);
//					String auth_real = String.valueOf(auth_ob_real);
//					Object auth_ob_stat = rsoid.getObject(4);
//					String auth_stat = String.valueOf(auth_ob_stat);
//					Object auth_ob_sub = rsoid.getObject(5);
//					String auth_sub = String.valueOf(auth_ob_sub);
//					Object auth_ob_prof = rsoid.getObject(6);
//					String auth_prof = String.valueOf(auth_ob_prof);
					
					auth_pass = auth_pass.replace("\n", "");
					
					System.out.println(auth_user + " " + auth_pass );
				}
			}
			
			my_db.commit();

		} catch(CUBRIDException e) {
			System.out.println(e);
		} catch(SQLException ex) {
		} finally {
			
			if(rs != null) try { rs.close(); } catch(SQLException e) {}
			if(stmt != null) try { stmt.close(); } catch(SQLException e) {}
			if(my_db != null) try { my_db.close(); } catch(SQLException e) {}
			
		}
		System.out.println(auth_sign);
		
		
		
	}
}