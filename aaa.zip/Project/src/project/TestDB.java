package project;
import java.sql.*;
import java.util.ArrayList;

import javax.print.attribute.standard.Destination;

import com.mysql.cj.x.protobuf.MysqlxCrud.Insert;
public class TestDB {
	
	public static void main(String[] args) {
		TestDB();
	}
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		static String url = "jdbc:mysql://127.0.0.1:3306/reservation";
		static String user = "manager01";
		static String pwd = "password01";
		

		
		
		
		
		public static Connection TestDB() {
			try {
				Class.forName("com.mysql.cj.jdbc.Driver"); // 6.0 ���� ���� 
				System.out.println("����̹� ���� ���� ");
				Connection con = DriverManager.getConnection(url, user, pwd);
				System.out.println("�����ͺ��̽� ���� ���� ");
				return con;
				
			} catch (Exception e) {
				System.out.println("�����ͺ��̽� ������� " + e.getMessage());
			}
			return null;		
		}
			

		public static void insertCustomer(String startingPoint, String destination, String departure_Date,
				String arrive_Date, String people) {
			try {
				Connection con = TestDB();
				PreparedStatement ps = con.prepareStatement(""
							+ "INSERT INTO userTestTBL2"
							+ "(startingPoint, destination, departure_Date, arrive_Date,people)"
							+ "VALUE"
							+ "('"+startingPoint+"','"+destination+"','"+departure_Date+"','"+arrive_Date+"','"+people+"')");
				ps.executeUpdate();
				System.out.println("Save");
					
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
		
		public static String[][] getFlight(){  // ������ �ҷ����� 
			try {
				Connection con = TestDB();
				
				String sql2 = "Select destination FROM userTestTBL2";
				
				String sql = "Select destination, departuretime, arrivaltime, price FROM flightTBL2";
				PreparedStatement statement = con.prepareStatement(sql);
				//PreparedStatement statement = con.prepareStatement(
				//		"Select destination, departuretime, arrivaltime, price FROM flightTBL2");
				
				ResultSet results = statement.executeQuery();
				
				ArrayList<String[]> list = new ArrayList<String[]>();				
				while(results.next()) {
					list.add(new String[] {
							
							// if("�̱�".equals(sql2)) 								
							results.getString("destination"),
							results.getString("departuretime"),
							results.getString("arrivaltime"),
							results.getString("price"),
							
					});
				}
				String[][] arr= new String[list.size()][4];
				return list.toArray(arr);
				
			}catch(Exception e) {
				System.out.println(e.getMessage());
				return null;
			}
	}
}