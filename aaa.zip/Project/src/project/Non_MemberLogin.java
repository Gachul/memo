package project;

import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.*;

public class Non_MemberLogin extends JFrame implements ActionListener {
	private JFrame f;
	private JPanel p;
	private JLabel noMemLgL, telL1, telL2;
	private JButton loginBtn, backBtn, homeBtn;
	private JTextField telF1, telF2, telF3;
	private JPasswordField pwF;
	private JLabel telL;
	private JLabel pwL;
	private static final String DB_URL = "jdbc:mysql://127.0.0.1:3306/reservation";
	private static final String USERNAME = "manager01";
	private static final String PASSWORD = "password01";

	Connection con = null;
	PreparedStatement ps = null;
	ResultSet rs = null;

	public Non_MemberLogin() {
		// ������
		f = new JFrame();
		f.setTitle("�װ��� ���� �ý��� - ��ȸ�� �α���");
		f.setBounds(100, 100, 800, 600);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.getContentPane().setLayout(null);
		f.setResizable(false);
		f.setLocationRelativeTo(null);

		// �г�
		p = new JPanel();
		p.setBounds(0, 0, 794, 571);
		f.getContentPane().add(p);
		p.setLayout(null);

		// ����
		noMemLgL = new JLabel("NON_MEMBER LOGIN");
		noMemLgL.setFont(new Font("����", Font.BOLD, 42));
		noMemLgL.setBounds(113, 125, 446, 67);
		p.add(noMemLgL);

		// �ڵ��� ��ȣ
		telL = new JLabel("�ڵ��� ��ȣ : ");
		telL.setFont(new Font("���ʷҵ���", Font.BOLD, 18));
		telL.setBounds(124, 243, 122, 48);
		telL.setHorizontalAlignment(SwingConstants.CENTER);
		p.add(telL);

		telF1 = new JTextField();
		telF1.setColumns(10);
		telF1.setBounds(258, 243, 63, 48);
		p.add(telF1);
		telL1 = new JLabel("-");
		telL1.setBounds(328, 259, 17, 15);
		p.add(telL1);

		telF2 = new JTextField();
		telF2.setColumns(10);
		telF2.setBounds(341, 243, 63, 48);
		p.add(telF2);
		telL2 = new JLabel("-");
		telL2.setBounds(410, 259, 17, 15);
		p.add(telL2);

		telF3 = new JTextField();
		telF3.setColumns(10);
		telF3.setBounds(423, 243, 63, 48);
		p.add(telF3);

		// ��й�ȣ
		pwL = new JLabel("PW : ");
		pwL.setFont(new Font("���ʷҵ���", Font.BOLD, 18));
		pwL.setBounds(183, 308, 63, 48);
		pwL.setHorizontalAlignment(SwingConstants.CENTER);
		p.add(pwL);
		pwF = new JPasswordField();
		pwF.setColumns(12);
		pwF.setBounds(258, 313, 228, 48);
		p.add(pwF);

		// ��ư
		loginBtn = new JButton("�α���");
		loginBtn.setBounds(511, 243, 122, 118);
		loginBtn.setFont(new Font("�Ȼ��2006����", Font.BOLD, 30));
		p.add(loginBtn);

		homeBtn = new JButton("");
		homeBtn.setSelectedIcon(
				new ImageIcon("C:\\Users\\user\\Documents\\JAVA\\Workspace\\project\\image\\homeBtn.png"));
		homeBtn.setIcon(new ImageIcon("C:\\Users\\user\\Documents\\JAVA\\Workspace\\project\\image\\homeBtn.png"));
		homeBtn.setBounds(729, 20, 41, 39);
		p.add(homeBtn);

		backBtn = new JButton("<");
		backBtn.setBounds(26, 500, 41, 39);
		p.add(backBtn);

		f.setVisible(true);

		// ������
		loginBtn.addActionListener(this);
		homeBtn.addActionListener(this);
		backBtn.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == loginBtn) {
			non_MemLogin();
		} else if (e.getSource() == backBtn) {
			new Login();
			f.dispose();
		} else if (e.getSource() == homeBtn) {
			new MainUI();
			f.dispose();
		}
	}

	public void non_MemLogin() {
		String sqlLogin = "SELECT userPw FROM memberTBL WHERE userTel = ?";

		if (telF1.getText().equals("") || telF2.getText().equals("") || telF3.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "�ڵ��� ��ȣ�� �Է��ϼ���");
			return;
		} else if (pwF.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "��й�ȣ�� �Է��ϼ���");
			return;
		}

		try {
			String userTel = telF1.getText() + "-" + telF2.getText() + "-" + telF3.getText();
			MemberDAO dao = new MemberDAO();
			dao.DBConnection();
			con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
			ps = con.prepareStatement(sqlLogin);
			ps.setString(1, userTel);
			rs = ps.executeQuery();

			if (rs.next()) {
				if (rs.getString(1).contentEquals(pwF.getText())) {
					JOptionPane.showMessageDialog(null, "�α��� �Ϸ�");
					JOptionPane.showMessageDialog(null, "�װ��� �˻� ������Ʈ ����");
				}
			} else
				JOptionPane.showMessageDialog(null, "�ڵ��� ��ȣ/��й�ȣ�� Ʋ�Ƚ��ϴ�");
		} catch (Exception e) {
			System.out.println("�α��� ����");
		}
	}
}