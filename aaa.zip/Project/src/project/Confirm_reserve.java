package project;

import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class Confirm_reserve extends JFrame implements ActionListener {

	private JFrame f;
	private JPanel p;
	private JScrollPane scrollPane;
	private JButton btn_rManage, btn_cancel;
	private JTable table;
	private static final String URL = "jdbc:mysql://localhost:3306/reservation";
	private static final String USER = "manager01";
	private static final String PW = "password01";
	Connection con = null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	
	String[] f_Col = { "�����ȣ", "�����", "������", "��߽ð�", "�����ð�", "����", "�¼�", "�ο�" };
	DefaultTableModel model = new DefaultTableModel(f_Col, 0);
	
	public Confirm_reserve() {

		

		f = new JFrame();
		f.setTitle("����Ȯ��");
		f.getContentPane().setBackground(Color.WHITE);
		f.getContentPane().setLayout(null);
		f.setBackground(Color.WHITE);
		f.setBounds(100, 100, 800, 600);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.getContentPane().setLayout(null);
		f.setResizable(false);
		f.setLocationRelativeTo(null);
		f.setVisible(true);

		p = new JPanel();
		p.setBounds(0, 0, 794, 571);
		f.getContentPane().add(p);
		p.setLayout(null);

		JLabel check = new JLabel("����� �װ���");
		check.setBounds(35, 24, 129, 15);
		check.setFont(new Font("����", Font.BOLD, 16));
		p.add(check);
		

		btn_rManage = new JButton("�������");
		btn_rManage.setBounds(171, 267, 90, 36);
		p.add(btn_rManage);

		btn_cancel = new JButton("���");
		btn_cancel.setBounds(298, 269, 90, 36);
		p.add(btn_cancel);

		table = new JTable(model);
		scrollPane = new JScrollPane(table);
		scrollPane.setSize(786, 500);
		p.add(scrollPane);
		DefaultTableModel m = (DefaultTableModel)table.getModel();
//		 m.insertRow(1, new Object[]{"d1","d2","d3"});

		btn_rManage.addActionListener(this);
		btn_cancel.addActionListener(this);
		select();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btn_rManage) {
			new F_cancel();
			f.dispose();
		} else if (e.getSource() == btn_cancel) {
			f.dispose();
			new ReserveMainP();
		}
	}

	private void select() {
		String sqlSelect = "SELECT * FROM ReserveTBL where userTel = ? ORDER BY date ASC";

		try {
			MemberDAO dao = new MemberDAO();
			dao.DBConnection();
			con = DriverManager.getConnection(URL, USER, PW);
			ps = con.prepareStatement(sqlSelect);
			ps.setString(1, Save_tel.tel);
			System.out.println(ps);
			rs = ps.executeQuery();
			System.out.println(model);
			while (rs.next()) {
				model.addRow(new Object[] { 
						rs.getString("reserveNum"), rs.getString("departure"), rs.getString("destination"),
						rs.getString("date"), rs.getString("depT"), rs.getString("arrT"),rs.getString("seat") });
			}
		} catch (Exception e) {
			System.out.println("�������� ����");
		} finally {
			try {
				rs.close();
				ps.close();
				con.close();
			} catch (Exception e) {
				System.out.println("���� ����");
			}
		}
	}

	public static void main(String[] args) {
		new Confirm_reserve();
	}
}