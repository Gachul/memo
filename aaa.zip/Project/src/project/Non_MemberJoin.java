package project;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class Non_MemberJoin extends JFrame implements ActionListener {
	JFrame f;
	JPanel p;
	JLabel noMemL, noMemNameL, noMemPwL;
	JLabel noMemTelL, noMemTelL1, noMemTelL2;
	JTextField noMemNameF;
	JTextField noMemTelF1, noMemTelF2, noMemTelF3;
	JPasswordField noMemPwF;
	JButton noMemLgBtn, noMemCancelBtn;

	public Non_MemberJoin() {
		// ������
		f = new JFrame();
		f.setTitle("�װ��� ���� �ý��� - ��ȸ�� ����");
		f.setBounds(100, 100, 800, 600);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.getContentPane().setLayout(null);
		f.setResizable(false);
		f.setLocationRelativeTo(null);
		f.setVisible(true);

		// �г�
		p = new JPanel();
		p.setBounds(0, 0, 794, 571);
		f.getContentPane().add(p);
		p.setLayout(null);

		// ����
		noMemL = new JLabel("��ȸ������");
		noMemL.setHorizontalAlignment(SwingConstants.CENTER);
		noMemL.setFont(new Font("����", Font.BOLD, 37));
		noMemL.setBounds(242, 69, 300, 47);
		p.add(noMemL);

		// �̸�
		noMemNameL = new JLabel("�̸� : ");
		noMemNameL.setHorizontalAlignment(SwingConstants.CENTER);
		noMemNameL.setBounds(230, 173, 52, 29);
		p.add(noMemNameL);
		noMemNameF = new JTextField();
		noMemNameF.setBounds(306, 173, 229, 29);
		p.add(noMemNameF);

		// ��й�ȣ
		noMemPwL = new JLabel("��й�ȣ : ");
		noMemPwL.setHorizontalAlignment(SwingConstants.CENTER);
		noMemPwL.setBounds(207, 252, 75, 29);
		p.add(noMemPwL);
		noMemPwF = new JPasswordField();
		noMemPwF.setBounds(306, 252, 229, 29);
		p.add(noMemPwF);
		noMemPwF.setColumns(12);

		// ����ó
		noMemTelL = new JLabel("����ó : ");
		noMemTelL.setHorizontalAlignment(SwingConstants.CENTER);
		noMemTelL.setBounds(219, 337, 63, 29);
		p.add(noMemTelL);

		noMemTelF1 = new JTextField();
		noMemTelF1.setBounds(306, 337, 65, 29);
		p.add(noMemTelF1);
		noMemTelL1 = new JLabel("-");
		noMemTelL1.setBounds(376, 344, 12, 15);
		p.add(noMemTelL1);

		noMemTelF2 = new JTextField();
		noMemTelF2.setBounds(389, 337, 65, 29);
		p.add(noMemTelF2);
		noMemTelL2 = new JLabel("-");
		noMemTelL2.setBounds(459, 344, 12, 15);
		p.add(noMemTelL2);

		noMemTelF3 = new JTextField();
		noMemTelF3.setBounds(470, 337, 65, 29);
		p.add(noMemTelF3);

		// ��ư
		noMemLgBtn = new JButton("��ȸ������");
		noMemLgBtn.setBounds(268, 424, 103, 38);
		p.add(noMemLgBtn);

		noMemCancelBtn = new JButton("���");
		noMemCancelBtn.setBounds(398, 424, 103, 38);
		p.add(noMemCancelBtn);

		// ������
		noMemLgBtn.addActionListener(this);
		noMemCancelBtn.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == noMemLgBtn) {
			if (noMemNameF.getText().trim().length() == 0) {
				JOptionPane.showMessageDialog(null, "�̸��� �Է��� �ּ���.", "�̸� �Է�", JOptionPane.WARNING_MESSAGE);
				noMemNameF.grabFocus();
				return;
			}
			if (noMemPwF.getText().trim().length() == 0) {
				JOptionPane.showMessageDialog(null, "��й�ȣ�� �Է��� �ּ���.", "��й�ȣ �Է�", JOptionPane.WARNING_MESSAGE);
				noMemPwF.grabFocus();
				return;
			}
			if (noMemTelF1.getText().trim().length() == 0) {
				JOptionPane.showMessageDialog(null, "��ȣ�� �Է��� �ּ���.", "��ȣ1 �Է�", JOptionPane.WARNING_MESSAGE);
				noMemTelF1.grabFocus();
				return;
			}
			if (noMemTelF2.getText().trim().length() == 0) {
				JOptionPane.showMessageDialog(null, "��ȣ�� �Է��� �ּ���.", "��ȣ2 �Է�", JOptionPane.WARNING_MESSAGE);
				noMemTelF2.grabFocus();
				return;
			}
			if (noMemTelF3.getText().trim().length() == 0) {
				JOptionPane.showMessageDialog(null, "��ȣ�� �Է��� �ּ���.", "��ȣ3 �Է�", JOptionPane.WARNING_MESSAGE);
				noMemTelF3.grabFocus();
				return;
			}
			noMemInsertMember();
		} else if (e.getSource() == noMemCancelBtn) {
			new Login();
			f.dispose();
		}
	}

	private void noMemInsertMember() {
		MemberDTO dto = getViewData();
		MemberDAO dao = new MemberDAO();
		boolean check = dao.noMemInsertMember(dto);

		if (check) {
			JOptionPane.showMessageDialog(null, "ȸ�������� �Ϸ�Ǿ����ϴ�.");
			new Non_MemberLogin();
			f.dispose();
		} else
			JOptionPane.showMessageDialog(null, "ȸ�����Կ� �����Ͽ����ϴ�.");
	}

	private MemberDTO getViewData() {
		MemberDTO dto = new MemberDTO();
		String userName = noMemNameF.getText();
		String userPw = noMemPwF.getText();
		String userTel1 = noMemTelF1.getText();
		String userTel2 = noMemTelF2.getText();
		String userTel3 = noMemTelF3.getText();
		String userTel = userTel1 + "-" + userTel2 + "-" + userTel3;

		dto.setUserPw(userPw);
		dto.setUserName(userName);
		dto.setUserTel(userTel);

		return dto;
	}
}