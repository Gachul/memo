package project;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.*;

public class MainUI extends JFrame implements ActionListener {
	
	JFrame f;
	JPanel p;
	JButton startBtn;
	ImagePanel imgP;

	public MainUI() {
		// ������
		f = new JFrame();
		f.setTitle("�װ��� ���� �ý��� - ���� ȭ��");
		f.getContentPane().setLayout(null);
		f.setResizable(false);

		// ���ȭ��
		imgP = new ImagePanel(new ImageIcon("./image/flight1.jpg").getImage());
		f.add(imgP);
		f.pack();

		// �г�
		p = new JPanel();
		p.setBounds(0, 0, 794, 571);
		f.getContentPane().add(p);
		p.setLayout(null);

		// ��ư
		startBtn = new JButton("Start");
		startBtn.setBounds(550, 400, 142, 39);
		p.add(startBtn);

		// ������
		f.setBounds(100, 100, 800, 600);
		f.setLocationRelativeTo(null);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);

		// ������
		startBtn.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == startBtn) {
			new Login();
			f.dispose();
		}
	}

	class ImagePanel extends JPanel {
		private Image img;

		public ImagePanel(Image img) {
			this.img = img;
			setSize(new Dimension(img.getWidth(null), img.getHeight(null)));
			setPreferredSize(new Dimension(img.getWidth(null), img.getHeight(null)));
			setLayout(null);
		}

		public void paintComponent(Graphics g) {
			g.drawImage(img, 0, 0, null);
		}
	}

	public static void main(String[] args) {
		List list_a = new ArrayList();
		list_a.add("hello");
		new MainUI();
	}
}