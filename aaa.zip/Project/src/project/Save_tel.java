package project;

public class Save_tel {
	public static String tel;
	
	public void s_tel(String s) {
		tel = s;
	}
}
