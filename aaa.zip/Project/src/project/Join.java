package project;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class Join extends JFrame implements ActionListener {
	JFrame f;
	JPanel p;
	JLabel joinL, idL, pwL, nameL, birthL, emailL, telL, addrL;
	JLabel yearL, monthL, telL1, telL2;
	JTextField idF, nameF, emailF, addrF;
	JTextField telF1, telF2, telF3;
	JTextField yearF, monthF, dateF;
	JPasswordField pwF;
	JButton joinBtn, cancelBtn;

	public Join() {
		joinUI();
	}

	private void joinUI() {
		// ������
		f = new JFrame();
		f.setTitle("�װ��� ���� �ý��� - ȸ������");
		f.setBounds(100, 100, 800, 600);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.getContentPane().setLayout(null);
		f.setResizable(false);
		f.setLocationRelativeTo(null);
		f.setVisible(true);

		// �г�
		p = new JPanel();
		p.setBounds(0, 0, 794, 571);
		f.getContentPane().add(p);
		p.setLayout(null);

		// ����
		joinL = new JLabel("ȸ������");
		joinL.setFont(new Font("����", Font.BOLD, 37));
		joinL.setHorizontalAlignment(SwingConstants.CENTER);
		joinL.setBounds(242, 22, 300, 47);
		p.add(joinL);

		// ���̵�
		idL = new JLabel("���̵� : ");
		idL.setHorizontalAlignment(SwingConstants.CENTER);
		idL.setBounds(259, 113, 63, 29);
		p.add(idL);
		idF = new JTextField();
		idF.setBounds(355, 113, 229, 29);
		p.add(idF);
		idF.setColumns(10);

		// ��й�ȣ
		pwL = new JLabel("��й�ȣ : ");
		pwL.setHorizontalAlignment(SwingConstants.CENTER);
		pwL.setBounds(247, 162, 75, 29);
		p.add(pwL);
		pwF = new JPasswordField();
		pwF.setBounds(355, 162, 229, 29);
		p.add(pwF);
		pwF.setColumns(12);

		// �̸�
		nameL = new JLabel("�̸� : ");
		nameL.setHorizontalAlignment(SwingConstants.CENTER);
		nameL.setBounds(270, 215, 52, 29);
		p.add(nameL);
		nameF = new JTextField();
		nameF.setColumns(10);
		nameF.setBounds(355, 215, 229, 29);
		p.add(nameF);

		// �������
		birthL = new JLabel("������� : ");
		birthL.setHorizontalAlignment(SwingConstants.CENTER);
		birthL.setBounds(247, 268, 75, 29);
		p.add(birthL);
		yearF = new JTextField();
		yearF.setColumns(10);
		yearF.setBounds(355, 272, 63, 29);
		p.add(yearF);
		yearL = new JLabel("��");
		yearL.setBounds(423, 282, 17, 15);
		p.add(yearL);

		monthF = new JTextField();
		monthF.setColumns(10);
		monthF.setBounds(438, 272, 63, 29);
		p.add(monthF);
		monthL = new JLabel("��");
		monthL.setBounds(505, 282, 17, 15);
		p.add(monthL);

		dateF = new JTextField();
		dateF.setColumns(10);
		dateF.setBounds(521, 272, 63, 29);
		p.add(dateF);

		// �̸���
		emailL = new JLabel("�̸��� : ");
		emailL.setHorizontalAlignment(SwingConstants.CENTER);
		emailL.setBounds(259, 321, 63, 29);
		p.add(emailL);
		emailF = new JTextField();
		emailF.setColumns(10);
		emailF.setBounds(355, 321, 229, 29);
		p.add(emailF);

		// ��ȭ��ȣ
		telL = new JLabel("����ó : ");
		telL.setHorizontalAlignment(SwingConstants.CENTER);
		telL.setBounds(259, 374, 63, 29);
		p.add(telL);

		telF1 = new JTextField();
		telF1.setColumns(10);
		telF1.setBounds(355, 378, 63, 29);
		p.add(telF1);
		telL1 = new JLabel("-");
		telL1.setBounds(425, 385, 17, 15);
		p.add(telL1);

		telF2 = new JTextField();
		telF2.setColumns(10);
		telF2.setBounds(441, 378, 63, 29);
		p.add(telF2);
		telL2 = new JLabel("-");
		telL2.setBounds(508, 385, 17, 15);
		p.add(telL2);

		telF3 = new JTextField();
		telF3.setColumns(10);
		telF3.setBounds(521, 378, 63, 29);
		p.add(telF3);

		// �ּ�
		addrF = new JTextField();
		addrF.setColumns(10);
		addrF.setBounds(355, 427, 229, 29);
		p.add(addrF);

		addrL = new JLabel("�ּ� : ");
		addrL.setHorizontalAlignment(SwingConstants.CENTER);
		addrL.setBounds(270, 427, 52, 29);
		p.add(addrL);

		// ��ư
		joinBtn = new JButton("ȸ������");
		joinBtn.setBounds(259, 484, 103, 38);
		p.add(joinBtn);

		cancelBtn = new JButton("���");
		cancelBtn.setBounds(439, 484, 103, 38);
		p.add(cancelBtn);

		joinBtn.addActionListener(this);
		cancelBtn.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == joinBtn) {
			if (idF.getText().trim().length() == 0) {
				JOptionPane.showMessageDialog(null, "���̵� �Է��� �ּ���.", "���̵� �Է�", JOptionPane.WARNING_MESSAGE);
				idF.grabFocus();
				return;
			}
			if (pwF.getText().trim().length() == 0) {
				JOptionPane.showMessageDialog(null, "��й�ȣ�� �Է��� �ּ���.", "��й�ȣ �Է�", JOptionPane.WARNING_MESSAGE);
				pwF.grabFocus();
				return;
			}
			if (nameF.getText().trim().length() == 0) {
				JOptionPane.showMessageDialog(null, "�̸��� �Է��� �ּ���.", "�̸� �Է�", JOptionPane.WARNING_MESSAGE);
				nameF.grabFocus();
				return;
			}
			if (telF1.getText().trim().length() == 0) {
				JOptionPane.showMessageDialog(null, "��ȣ�� �Է��� �ּ���.", "��ȣ1 �Է�", JOptionPane.WARNING_MESSAGE);
				telF1.grabFocus();
				return;
			}
			if (telF2.getText().trim().length() == 0) {
				JOptionPane.showMessageDialog(null, "��ȣ�� �Է��� �ּ���.", "��ȣ2 �Է�", JOptionPane.WARNING_MESSAGE);
				telF2.grabFocus();
				return;
			}
			if (telF3.getText().trim().length() == 0) {
				JOptionPane.showMessageDialog(null, "��ȣ�� �Է��� �ּ���.", "��ȣ3 �Է�", JOptionPane.WARNING_MESSAGE);
				telF3.grabFocus();
				return;
			}
			insertMember();
		} else if (e.getSource() == cancelBtn) {
			new Login();
			f.dispose();
		}
	}

	private void insertMember() {
		MemberDTO dto = getViewData();
		MemberDAO dao = new MemberDAO();
		boolean check = dao.insertMember(dto);

		if (check) {
			JOptionPane.showMessageDialog(null, "ȸ�������� �Ϸ�Ǿ����ϴ�.");
			new Login();
			f.dispose();
		} else
			JOptionPane.showMessageDialog(null, "ȸ�����Կ� �����Ͽ����ϴ�.");
	}

	public MemberDTO getViewData() {
		MemberDTO dto = new MemberDTO();
		String userId = idF.getText();
		String userPw = pwF.getText();
		String userName = nameF.getText();
		String userBirth1 = yearF.getText();
		String userBirth2 = monthF.getText();
		String userBirth3 = dateF.getText();
		String userBirth = userBirth1 + userBirth2 + userBirth3;
		String userEmail = emailF.getText();
		String userTel1 = telF1.getText();
		String userTel2 = telF2.getText();
		String userTel3 = telF3.getText();
		String userTel = userTel1 + "-" + userTel2 + "-" + userTel3;
		String userAddr = addrF.getText();

		dto.setUserId(userId);
		dto.setUserPw(userPw);
		dto.setUserName(userName);
		dto.setUserBirth(userBirth);
		dto.setUserEmail(userEmail);
		dto.setUserTel(userTel);
		dto.setUserAddr(userAddr);

		return dto;
	}
}