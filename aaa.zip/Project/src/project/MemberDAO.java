package project;

import java.sql.*;
import java.util.*;

public class MemberDAO {
	private static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
	private static final String DB_URL = "jdbc:mysql://127.0.0.1:3306/reservation";
	private static final String USERNAME = "manager01";
	private static final String PASSWORD = "password01";

	Connection con = null;
	PreparedStatement ps = null;
	ResultSet rs = null;

	public MemberDAO() {
	}

	// DB ����
	public Connection DBConnection() {
		try {
			Class.forName(JDBC_DRIVER);
			System.out.println("jdbc ����̹� ���� �Ϸ�");
			con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
			System.out.println("DB ���� ����");
		} catch (ClassNotFoundException e) {
			System.out.println("jdbc ����̹� �ε� ����");
		} catch (SQLException e) {
			System.out.println("DB ���ӽ���" + e.getMessage());
		} catch (Exception e) {
			System.out.println("Unknown error");
		}
		return con;
	}

	// ȸ�� ����
	public boolean insertMember(MemberDTO dto) {
		boolean check = false;

		try {
			con = DBConnection();

			String sqlInsert = "INSERT INTO memberTBL"
					+ "(userid, userpw, username, userbirth, useremail, usertel, useraddr) "
					+ "VALUES(?, ?, ?, ?, ?, ?, ?)";

			ps = con.prepareStatement(sqlInsert);
			ps.setString(1, dto.getUserId());
			ps.setString(2, dto.getUserPw());
			ps.setString(3, dto.getUserName());
			ps.setString(4, dto.getUserBirth());
			ps.setString(5, dto.getUserEmail());
			ps.setString(6, dto.getUserTel());
			ps.setString(7, dto.getUserAddr());
			int rs = ps.executeUpdate(); // ���� -> ����

			if (rs > 0) {
				System.out.println("���� ����");
				check = true;
			} else
				System.out.println("���� ����");
		} catch (Exception e) {
			System.out.println("ȸ�� ��� ����");
		}
		return check;
	}

	// ��ȸ�� ����
	public boolean noMemInsertMember(MemberDTO dto) {
		boolean check = false;

		try {
			con = DBConnection();

			String sqlInsert = "INSERT INTO memberTBL" + "(userpw, username, usertel) " + "VALUES(?, ?, ?)";

			ps = con.prepareStatement(sqlInsert);
			ps.setString(1, dto.getUserPw());
			ps.setString(2, dto.getUserName());
			ps.setString(3, dto.getUserTel());
			int rs = ps.executeUpdate(); // ���� -> ����

			if (rs > 0) {
				System.out.println("���� ����");
				check = true;
			} else
				System.out.println("���� ����");
		} catch (Exception e) {
			System.out.println("ȸ�� ��� ����");
		}
		return check;
	}

	// ��� ��������
	public MemberDTO getMemberDTO(String userId) {
		MemberDTO dto = new MemberDTO();

		try {
			con = DBConnection();
			String sqlSelect = "SELECT * FROM memberTBL where id = ?";
			ps = con.prepareStatement(sqlSelect);
			ps.setString(1, userId);

			rs = ps.executeQuery();

			if (rs.next()) {
				dto.setUserId(rs.getString("userId"));
				dto.setUserPw(rs.getString("userPw"));
				dto.setUserName(rs.getString("userName"));
				dto.setUserBirth(rs.getString("userBirth"));
				dto.setUserEmail(rs.getString("userEmail"));
				dto.setUserTel(rs.getString("userTel"));
				dto.setUserAddr(rs.getString("userAddr"));
			}
		} catch (Exception e) {
			System.out.println("���� �������� ����");
		}
		return dto;
	}
}