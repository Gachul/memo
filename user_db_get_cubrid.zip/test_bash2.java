import cubrid.jdbc.driver.*;
import cubrid.sql.*;
import java.sql.*;

public class test_bash2
{

	public static void main(String[] args) {
		String auth_sign = "01";
		
		String url= "jdbc:cubrid:192.168.255.78:33000:insadb:::";
		String user = "fmxuser";
		String passwd = "fmxuser!2";
		
		String req_id = args[0];
		String sql = "SELECT wifi_user from wifi_user where id = \'" + req_id + "\'";
		String[] attr = {"id"} ;


		// ����� ���� ����
		Connection my_db = null;
		Statement stmt = null;
		CUBRIDResultSet rs = null;

		try {
			Class.forName("cubrid.jdbc.driver.CUBRIDDriver");
		} catch (ClassNotFoundException e) {
			throw new IllegalStateException("Unable to load Cubrid driver", e);
		}

		try {
			// db ���� �κ�
			my_db = DriverManager.getConnection(url, user, passwd);
			stmt = my_db.createStatement();
			rs = (CUBRIDResultSet)stmt.executeQuery(sql);
			// �� ���
			CUBRIDResultSet rsoid = null;
			while (rs.next()) {
				CUBRIDOID oid = rs.getOID(1);
				rsoid = (CUBRIDResultSet)oid.getValues(attr);

				while (rsoid.next()) {
					Object auth_ob_id = rsoid.getObject(1);
					String auth_id = String.valueOf(auth_ob_id);

					if(req_id.equals(auth_id)) {
						auth_sign = "00";
					}
				}
				if(auth_sign == "00") {
					break;
				}
			}

		} catch(CUBRIDException e) {
			System.out.println(e);
		} catch(SQLException ex) {
		} finally {
			if(rs != null) try { rs.close(); } catch(SQLException e) {}
			if(stmt != null) try { stmt.close(); } catch(SQLException e) {}
			if(my_db != null) try { my_db.close(); } catch(SQLException e) {}
		}
		System.out.println(auth_sign);
	}
}