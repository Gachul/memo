package project;

import java.awt.event.*;

import javax.swing.*;

public class SeatPage extends JFrame implements ActionListener {

	private JFrame frame;

	public SeatPage() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setTitle("�װ��� �����ϱ� - 3");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(100, 100, 800, 600);
		frame.setResizable(false);
		frame.setLocationRelativeTo(null);
		frame.getContentPane().setLayout(null);

		JPanel seatPanel = new JPanel();
		seatPanel.setBounds(0, 0, 794, 571);
		frame.getContentPane().add(seatPanel);
		seatPanel.setLayout(null);

		JButton a1 = new JButton("A1");
		a1.setBounds(58, 35, 52, 23);
		seatPanel.add(a1);

		JButton b1 = new JButton("B1");
		b1.setBounds(117, 34, 52, 23);
		seatPanel.add(b1);

		JButton b2 = new JButton("B2");
		b2.setBounds(117, 67, 52, 23);
		seatPanel.add(b2);

		JButton a2 = new JButton("A2");
		a2.setBounds(58, 67, 52, 23);
		seatPanel.add(a2);

		JButton a3 = new JButton("A3");
		a3.setBounds(58, 100, 52, 23);
		seatPanel.add(a3);

		JButton b3 = new JButton("B3");
		b3.setBounds(117, 100, 52, 23);
		seatPanel.add(b3);

		JButton a4 = new JButton("A4");
		a4.setBounds(58, 128, 52, 23);
		seatPanel.add(a4);

		JButton b4 = new JButton("B4");
		b4.setBounds(117, 128, 52, 23);
		seatPanel.add(b4);

		JButton a5 = new JButton("A5");
		a5.setBounds(58, 161, 52, 23);
		seatPanel.add(a5);

		JButton b5 = new JButton("B5");
		b5.setBounds(117, 161, 52, 23);
		seatPanel.add(b5);

		JButton a6 = new JButton("A6");
		a6.setBounds(58, 194, 52, 23);
		seatPanel.add(a6);

		JButton b6 = new JButton("B6");
		b6.setBounds(117, 194, 52, 23);
		seatPanel.add(b6);

		JButton c1 = new JButton("C1");
		c1.setBounds(203, 35, 52, 23);
		seatPanel.add(c1);

		JButton d1 = new JButton("D1");
		d1.setBounds(267, 35, 52, 23);
		seatPanel.add(d1);

		JButton c2 = new JButton("C2");
		c2.setBounds(203, 67, 52, 23);
		seatPanel.add(c2);

		JButton d2 = new JButton("D2");
		d2.setBounds(267, 67, 52, 23);
		seatPanel.add(d2);

		JButton c3 = new JButton("C3");
		c3.setBounds(203, 100, 52, 23);
		seatPanel.add(c3);

		JButton d3 = new JButton("D3");
		d3.setBounds(267, 100, 52, 23);
		seatPanel.add(d3);

		JButton c4 = new JButton("C4");
		c4.setBounds(203, 128, 52, 23);
		seatPanel.add(c4);

		JButton c5 = new JButton("C6");
		c5.setBounds(203, 161, 52, 23);
		seatPanel.add(c5);

		JButton c6 = new JButton("C6");
		c6.setBounds(203, 194, 52, 23);
		seatPanel.add(c6);

		JButton d4 = new JButton("D4");
		d4.setBounds(267, 128, 52, 23);
		seatPanel.add(d4);

		JButton d5 = new JButton("D5");
		d5.setBounds(267, 161, 52, 23);
		seatPanel.add(d5);

		JButton d6 = new JButton("D6");
		d6.setBounds(267, 194, 52, 23);
		seatPanel.add(d6);

		ButtonGroup bd = new ButtonGroup();
		bd.add(a1);
		bd.add(a2);
		bd.add(a3);
		bd.add(a4);
		bd.add(a5);
		bd.add(a6);
		bd.add(b1);
		bd.add(b2);
		bd.add(b3);
		bd.add(b4);
		bd.add(b5);
		bd.add(c1);
		bd.add(c2);
		bd.add(c3);
		bd.add(c4);
		bd.add(c4);
		bd.add(c6);
		bd.add(d1);
		bd.add(d2);
		bd.add(d3);
		bd.add(d4);
		bd.add(d5);
		bd.add(d6);

		JButton btnA[] = { a1, a2, a3, a4, a5, a6, b1, b2, b3, b4, b5, b6, c1, c2, c3, c4, c5, c6, d1, d2, d3, d4, d5,
				d6 };

		JLabel departureSeat = new JLabel("�¼��� �������ּ���");
		departureSeat.setBounds(215, 377, 155, 15);
		seatPanel.add(departureSeat);

		JLabel seatpo_1 = new JLabel("����ϴ³� �¼� :");
		seatpo_1.setBounds(100, 377, 103, 15);
		seatPanel.add(seatpo_1);

		JLabel seatpo_1_1 = new JLabel("���ƿ��³� �¼�:");
		seatpo_1_1.setBounds(100, 430, 103, 15);
		seatPanel.add(seatpo_1_1);

		JLabel arriveSeat = new JLabel("�¼��� �������ּ���");
		arriveSeat.setBounds(215, 430, 155, 15);
		seatPanel.add(arriveSeat);

		JLabel seatpo_1_1_1 = new JLabel("����ϴ³� �¼� ����");
		seatpo_1_1_1.setBounds(58, 10, 133, 15);
		seatPanel.add(seatpo_1_1_1);

		JLabel seatpo_1_1_1_1 = new JLabel("���ƿ��³� �¼� ����");
		seatpo_1_1_1_1.setBounds(428, 10, 133, 15);
		seatPanel.add(seatpo_1_1_1_1);

		JButton a1_1 = new JButton("A1");
		a1_1.setBounds(419, 35, 52, 23);
		seatPanel.add(a1_1);

		JButton d6_1 = new JButton("D6");
		d6_1.setBounds(628, 194, 52, 23);
		seatPanel.add(d6_1);

		JButton a2_1 = new JButton("A2");
		a2_1.setBounds(419, 67, 52, 23);
		seatPanel.add(a2_1);

		JButton b1_1 = new JButton("B1");
		b1_1.setBounds(478, 34, 52, 23);
		seatPanel.add(b1_1);

		JButton b2_1 = new JButton("B2");
		b2_1.setBounds(478, 67, 52, 23);
		seatPanel.add(b2_1);

		JButton a3_1 = new JButton("A3");
		a3_1.setBounds(419, 100, 52, 23);
		seatPanel.add(a3_1);

		JButton b3_1 = new JButton("B3");
		b3_1.setBounds(478, 100, 52, 23);
		seatPanel.add(b3_1);

		JButton b4_1 = new JButton("B4");
		b4_1.setBounds(478, 128, 52, 23);
		seatPanel.add(b4_1);

		JButton a4_1 = new JButton("A4");
		a4_1.setBounds(419, 128, 52, 23);
		seatPanel.add(a4_1);

		JButton a5_1 = new JButton("A5");
		a5_1.setBounds(419, 161, 52, 23);
		seatPanel.add(a5_1);

		JButton b5_1 = new JButton("B5");
		b5_1.setBounds(478, 161, 52, 23);
		seatPanel.add(b5_1);

		JButton b6_1 = new JButton("B6");
		b6_1.setBounds(478, 194, 52, 23);
		seatPanel.add(b6_1);

		JButton a6_1 = new JButton("A6");
		a6_1.setBounds(419, 194, 52, 23);
		seatPanel.add(a6_1);

		JButton c6_1 = new JButton("C6");
		c6_1.setBounds(564, 194, 52, 23);
		seatPanel.add(c6_1);

		JButton c5_1 = new JButton("C6");
		c5_1.setBounds(564, 161, 52, 23);
		seatPanel.add(c5_1);

		JButton d5_1 = new JButton("D5");
		d5_1.setBounds(628, 161, 52, 23);
		seatPanel.add(d5_1);

		JButton d4_1 = new JButton("D4");
		d4_1.setBounds(628, 128, 52, 23);
		seatPanel.add(d4_1);

		JButton c4_1 = new JButton("C4");
		c4_1.setBounds(564, 128, 52, 23);
		seatPanel.add(c4_1);

		JButton c3_1 = new JButton("C3");
		c3_1.setBounds(564, 100, 52, 23);
		seatPanel.add(c3_1);

		JButton d3_1 = new JButton("D3");
		d3_1.setBounds(628, 100, 52, 23);
		seatPanel.add(d3_1);

		JButton d2_1 = new JButton("D2");
		d2_1.setBounds(628, 67, 52, 23);
		seatPanel.add(d2_1);

		JButton c2_1 = new JButton("C2");
		c2_1.setBounds(564, 67, 52, 23);
		seatPanel.add(c2_1);

		JButton c1_1 = new JButton("C1");
		c1_1.setBounds(564, 35, 52, 23);
		seatPanel.add(c1_1);

		JButton d1_1 = new JButton("D1");
		d1_1.setBounds(628, 35, 52, 23);
		seatPanel.add(d1_1);

		JButton btnNewButton = new JButton("Ȯ��");
		btnNewButton.setBounds(419, 426, 133, 23);
		seatPanel.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("���");
		btnNewButton_1.setBounds(564, 426, 91, 23);
		seatPanel.add(btnNewButton_1);
		frame.setVisible(true);

		a1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				departureSeat.setText(a1.getText());

			}
		});
		a2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				departureSeat.setText(a2.getText());

			}
		});
		a3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				departureSeat.setText(a3.getText());

			}
		});
		a4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				departureSeat.setText(a4.getText());

			}
		});
		a5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				departureSeat.setText(a5.getText());

			}
		});
		a6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				departureSeat.setText(a6.getText());

			}
		});
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				departureSeat.setText(b1.getText());

			}
		});
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				departureSeat.setText(b2.getText());

			}
		});
		b3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				departureSeat.setText(b3.getText());

			}
		});
		b4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				departureSeat.setText(d4.getText());

			}
		});
		b5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				departureSeat.setText(b5.getText());

			}
		});
		b6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				departureSeat.setText(b6.getText());

			}
		});

		c1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				departureSeat.setText(c1.getText());

			}
		});

		c2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				departureSeat.setText(c3.getText());

			}
		});

		c4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				departureSeat.setText(c4.getText());

			}
		});

		c5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				departureSeat.setText(c5.getText());

			}
		});

		c6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				departureSeat.setText(c6.getText());

			}
		});

		d1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				departureSeat.setText(d1.getText());

			}
		});

		d2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				departureSeat.setText(d2.getText());

			}
		});

		d3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				departureSeat.setText(d3.getText());

			}
		});

		d4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				departureSeat.setText(d5.getText());

			}
		});

		d6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				departureSeat.setText(d6.getText());

			}
		});

		a1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				arriveSeat.setText(a1_1.getText());

			}
		});
		a2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				arriveSeat.setText(a2_1.getText());

			}
		});
		a3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				arriveSeat.setText(a3_1.getText());

			}
		});
		a4_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				arriveSeat.setText(a4_1.getText());

			}
		});
		a5_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				arriveSeat.setText(a5_1.getText());

			}
		});
		a6_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				arriveSeat.setText(a6_1.getText());

			}
		});
		b1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				arriveSeat.setText(b1_1.getText());

			}
		});
		b2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				arriveSeat.setText(b2_1.getText());

			}
		});
		b3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				arriveSeat.setText(b3_1.getText());

			}
		});
		b4_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				arriveSeat.setText(d4_1.getText());

			}
		});
		b5_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				arriveSeat.setText(b5_1.getText());

			}
		});
		b6_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				arriveSeat.setText(b6_1.getText());

			}
		});

		c1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				arriveSeat.setText(c1_1.getText());

			}
		});

		c2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				arriveSeat.setText(c3_1.getText());

			}
		});

		c4_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				arriveSeat.setText(c4_1.getText());

			}
		});

		c5_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				arriveSeat.setText(c5_1.getText());

			}
		});

		c6_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				arriveSeat.setText(c6_1.getText());

			}
		});

		d1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				arriveSeat.setText(d1_1.getText());

			}
		});

		d2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				arriveSeat.setText(d2_1.getText());

			}
		});

		d3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				departureSeat.setText(d3_1.getText());

			}
		});

		d4_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				departureSeat.setText(d5_1.getText());

			}
		});

		d6_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				arriveSeat.setText(d6_1.getText());

			}
		});
	}
}