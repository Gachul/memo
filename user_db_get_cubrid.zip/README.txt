<Cubrid DB에 직접 인증 방식>

0. cd /tmp/
0-1. mkdir wiz
0-2. cd wiz/

1. 대상 Cubrid Database version에 맞는 JDBC driver를 다운받는다.

[Java 사용]
2-1. 입력값을 받아 Cubrid DB에 접속 후 테이블에 입력값과 매칭되는 값이 존재하면 특정한 값을 출력하는 코드를 작성한다.
[test_bash.java]

[cd /usr/local/bin/]
2-2. external_pap_check를 수정한다. 
 >> my $check_auth 부분에 2-1에서 작성한 코드의 실행 명령을 입력한다.
 >> 나머지 코드를 2-1에서 작성한 코드에 호환되도록 수정한다.

3. external_mtauth.pl의 일부분을 mtauth.pl에 삽입한다.
 >> mtauth.pl의 authorize 부분의 profid 0일 때 실행되는 문구 밑에
 >> extrnal_mtauth.pl의 (authorize - profid 3 > if 문)을 삽입

4. lib폴더 내부의 rlm_pap_external.so 파일을 rlm_pap.so 파일에 덮어 씌운다.

#########################################################

<Cubrid DB의 접속정보를 가져와서 Local DB에서 자체 인증을 하는 방식>

1. 대상 Cubrid DB version JDBC driver를 다운받는다.
	
2-1. Cubrid DB의 값을 가져오는 코드를 작성한다.
(전부는 아니고 일정 범위를 지정해준다.)

2-2. Cubrid 와 Local DB의 매칭할 값이 담긴 파일을 생성할 코드를 작성한다.
(cub.pl)

3. user_db_get.sh 파일을 Cubrid와 Local DB의 값을 비교하여 Local DB의 데이터를 갱신하는 방향으로 수정한다.
>> Cleartext-Password 와 SHA2-Password를 구분해준다.
>> Attribute에 따라 복호화하는 방식을 다르게 해줘야 함을 구분할 때 쓰인다.
>> 기본적으로 SHA2의 경우 sha256 이후 base64로 한번 더 암호화 한다.

4. 위를 수정하여 Cubrid가 아닌 다른 DB에서도 값을 가져올 수 있도록 만들 수 있다.
이때, cub.pl파일도 같이 수정해준다.