package project;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class FlightPage  extends JFrame implements MouseListener, ActionListener {

	private JFrame frame;
	private JTable departureTable;
	private JTable arriveTable;
	private JTable table;
	private JTable arriveTable2;
	public FlightPage() {
		
			frame = new JFrame();
		JPanel panel = new JPanel();
		
		String[] headings = new String[] { "������", "��߽ð�", "�����ð�", "����"};
		String[][] data =TestDB.getFlight();
		/*
		Object data[][]= new Object[][]{ { "(row0,column0)","(row0,column1)","(row0,column2)","(row0,column3)"},
				  { "(row1,column0)","(row1,column1)","(row1,column2)","(row1,column3)"},
				  { "(row2,column0)","(row2,column1)","(row2,column2)","(row2,column3)"},
				  { "(row3,column0)","(row3,column1)","(row3,column2)","(row3,column3)"},
		};
		*/
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		frame.setVisible(true);
		frame.setSize(800,640);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel flightPanel = new JPanel();
		flightPanel.setLayout(null);
		
		JTable departureData = new JTable(data,headings);
		departureData.setFillsViewportHeight(true);
		departureData.setBounds(103, 37, 540, 457);
		JScrollPane scrollPane_1 = new JScrollPane(departureData);
		
		
		scrollPane_1.setBounds(69, 37, 620, 199);
		flightPanel.add(scrollPane_1);
		frame.getContentPane().add(flightPanel);
		
		
		
		
		
		JButton btnNewButton = new JButton("Ȯ��");
		
		btnNewButton.setBounds(527, 517, 70, 23);
		flightPanel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("���");
		btnNewButton_1.setBounds(609, 517, 70, 23);
		flightPanel.add(btnNewButton_1);
		
		JLabel lblNewLabel = new JLabel("��� �װ��� ����");
		lblNewLabel.setBounds(69, 21, 137, 15);
		flightPanel.add(lblNewLabel);
		
		JLabel destination = new JLabel("New label");
		destination.setBounds(69, 506, 64, 15);
		flightPanel.add(destination);
		
		JLabel dtField = new JLabel("New label");
		dtField.setBounds(145, 506, 70, 15);
		flightPanel.add(dtField);
		
		JLabel atField = new JLabel("New label");
		atField.setBounds(231, 506, 70, 15);
		flightPanel.add(atField);
		
		JLabel priceField = new JLabel("New label");
		priceField.setBounds(313, 506, 70, 15);
		flightPanel.add(priceField);
		
		departureData.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int idx = departureData.getSelectedRow();
				destination.setText((String) departureData.getValueAt(idx,0)+"");
				dtField.setText((String) departureData.getValueAt(idx,1)+"");
				atField.setText((String) departureData.getValueAt(idx,2)+"");
				priceField.setText((String) departureData.getValueAt(idx,2)+"");
				
			}
		});
		
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String dt = dtField.getText();
				String at = atField.getText();
				String price = priceField.getText();
				
				TestDB.insertCustomer(dt, at, price, price, price);
				JOptionPane.showMessageDialog(null,"���� �Ϸ�" );
				
				
			}
		});
		
		frame.setVisible(true);
	}
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}