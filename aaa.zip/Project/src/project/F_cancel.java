package project;

import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class F_cancel extends JFrame implements ActionListener {

	private JFrame f;
	private JPanel p;
	private JTextField t_departure, t_destination, t_depDate, t_arrDate, t_seat, t_totalNum;
	private JButton btn_cReserve, btn_cancel;
	private static final String url = "jdbc:mysql://localhost:3306/reservation";
	private static final String user = "manager01";
	private static final String pw = "password01";
	Connection con = null;

	public F_cancel() {
		f = new JFrame();
		f.setTitle("�������");
		f.getContentPane().setBackground(Color.WHITE);
		f.getContentPane().setLayout(null);
		f.setBounds(100, 100, 800, 600);
		
		JPanel p = new JPanel();
		p.setBounds(0, 0, 794, 571);
		f.getContentPane().add(p);
		p.setLayout(null);

		JLabel check = new JLabel("�� �װ��� ����");
		check.setBounds(35, 24, 129, 15);
		check.setFont(new Font("����", Font.BOLD, 16));
		p.add(check);

		JLabel lb1 = new JLabel("�����");
		lb1.setBounds(45, 55, 85, 15);
		p.add(lb1);

		JLabel lb2 = new JLabel("������");
		lb2.setBounds(326, 55, 85, 15);
		p.add(lb2);

		t_departure = new JTextField();
		t_departure.setBounds(45, 77, 182, 36);
		t_departure.setToolTipText("");
		p.add(t_departure);
		t_departure.setColumns(10);

		JLabel lb3 = new JLabel("��");
		lb3.setBounds(263, 80, 19, 27);
		lb3.setFont(new Font("����", Font.BOLD, 18));
		p.add(lb3);

		t_destination = new JTextField();
		t_destination.setBounds(326, 77, 182, 36);
		t_destination.setColumns(10);
		p.add(t_destination);

		JLabel lb5 = new JLabel("��߳�¥ �� �ð�");
		lb5.setBounds(45, 137, 85, 15);
		p.add(lb5);

		JLabel lb6 = new JLabel("������¥ �� �ð�");
		lb6.setBounds(326, 137, 85, 15);
		p.add(lb6);

		t_depDate = new JTextField();
		t_depDate.setToolTipText("");
		t_depDate.setColumns(10);
		t_depDate.setBounds(45, 158, 182, 36);
		p.add(t_depDate);

		t_arrDate = new JTextField();
		t_arrDate.setColumns(10);
		t_arrDate.setBounds(326, 158, 182, 36);
		p.add(t_arrDate);

		btn_cReserve = new JButton("�������");
		btn_cReserve.setBounds(182, 308, 90, 36);
		p.add(btn_cReserve);

		JCheckBox checking = new JCheckBox("������ ����Ͻðڽ��ϱ�?");
		checking.setBounds(45, 279, 194, 23);
		p.add(checking);

		JLabel lb7 = new JLabel("�¼�");
		lb7.setBounds(45, 229, 62, 15);
		p.add(lb7);

		t_seat = new JTextField();
		t_seat.setToolTipText("");
		t_seat.setColumns(10);
		t_seat.setBounds(86, 219, 90, 36);
		p.add(t_seat);

		JLabel lb8 = new JLabel("�ο���");
		lb8.setBounds(210, 229, 62, 15);
		p.add(lb8);

		t_totalNum = new JTextField();
		t_totalNum.setToolTipText("");
		t_totalNum.setColumns(10);
		t_totalNum.setBounds(263, 219, 90, 36);
		p.add(t_totalNum);

		btn_cancel = new JButton("���");
		btn_cancel.setBounds(289, 308, 90, 36);
		p.add(btn_cancel);

		f.setBackground(Color.WHITE);
		f.setBounds(100, 100, 600, 405);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		f.getContentPane().setLayout(null);
		f.setResizable(false);
		f.setLocationRelativeTo(null);
		f.setVisible(true);

		btn_cReserve.addActionListener(this);
		btn_cancel.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btn_cReserve) {
			JOptionPane.showMessageDialog(null, "������ ����Ͻðڽ��ϱ�?");
			return;
		} else if (e.getSource() == btn_cancel) {
			new Confirm_reserve();
			f.dispose();
		}
	}

//	public static void main(String[] args) {
//		new F_cancel();
//	}
}