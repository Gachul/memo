import cubrid.jdbc.driver.*;
import cubrid.sql.*;
import java.sql.*;

public class test_bash
{

	public static void main(String[] args) {
		String auth_sign = "01";
		
		String url= "jdbc:cubrid:192.168.255.78:33000:insadb:::";
		String user = "fmxuser";
		String passwd = "fmxuser!2";
		
		String req_id = "beta";
		String req_user = "ten";
		
		String sql = "SELECT wifi_user from wifi_user where id = \'" + req_id + "\' and user_name = \'" + req_user + "\'";
		
		String[] attr = {"user_name" };

		// ����� ���� ����
		Connection my_db = null;
		Statement stmt = null;
		CUBRIDResultSet rs = null;

		try {
			Class.forName("cubrid.jdbc.driver.CUBRIDDriver");
		} catch (ClassNotFoundException e) {
			throw new IllegalStateException("Unable to load Cubrid driver", e);
		}

		try {
			// db ���� �κ�
			my_db = DriverManager.getConnection(url, user, passwd);
			stmt = my_db.createStatement();
			
			rs = (CUBRIDResultSet)stmt.executeQuery(sql);
			
			if(rs.next()) {
				auth_sign = "00";
				
				CUBRIDResultSet rsoid = null;

				CUBRIDOID oid = rs.getOID(1);
				rsoid = (CUBRIDResultSet)oid.getValues(attr);
				while (rsoid.next()) {
					Object auth_ob_user = rsoid.getObject(1);
					String auth_user = String.valueOf(auth_ob_user);
					
					System.out.println(auth_user);
				}
			}
			
			my_db.commit();

		} catch(CUBRIDException e) {
		} catch(SQLException ex) {
		} finally {
			
			if(rs != null) try { rs.close(); } catch(SQLException e) {}
			if(stmt != null) try { stmt.close(); } catch(SQLException e) {}
			if(my_db != null) try { my_db.close(); } catch(SQLException e) {}
			
		}
		System.out.println(auth_sign);
		
		
		
	}
}