package project;

import java.awt.event.*;
import java.sql.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class CusManage extends JPanel implements ActionListener {
	private static final long serialVersionUID = 1L;
	private JButton deleteBtn, cancelBtn;
	private JTable table;
	private JScrollPane scrollPane;
	private JFrame f;
	private JPanel p;

	private String colNames[] = { "���̵�", "��й�ȣ", "�̸�", "����", "�̸���", "��ȭ��ȣ", "�ּ�" };
	private DefaultTableModel model = new DefaultTableModel(colNames, 0);
	private static final String DB_URL = "jdbc:mysql://127.0.0.1:3306/reservation";
	private static final String USERNAME = "manager01";
	private static final String PASSWORD = "password01";

	Connection con = null;
	PreparedStatement ps = null;
	ResultSet rs = null;

	public CusManage() {
		// ������
		f = new JFrame();
		f.setTitle("�װ��� ���� �ý��� - ������ �޴�(ȸ�� ����)");
		f.setBounds(100, 100, 800, 600);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.getContentPane().setLayout(null);
		f.setResizable(false);
		f.setLocationRelativeTo(null);

		// �г�
		p = new JPanel();
		f.add(p);
		p.setBounds(0, 0, 794, 571);
		p.setLayout(null);

		// ���̺�
		setLayout(null);
		table = new JTable(model);
		table.addMouseListener(new JTableMouseListener());
		scrollPane = new JScrollPane(table);
		scrollPane.setSize(786, 500);
		p.add(scrollPane);

		// ��ư
		deleteBtn = new JButton();
		deleteBtn.setBounds(224, 510, 142, 39);
		deleteBtn.setText("ȸ�� ����");
		p.add(deleteBtn);

		cancelBtn = new JButton("���");
		cancelBtn.setBounds(424, 510, 142, 39);
		p.add(cancelBtn);

		// ������
		deleteBtn.addActionListener(this);
		cancelBtn.addActionListener(this);
		select();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == deleteBtn) {
			deleteMember();
			JOptionPane.showMessageDialog(null, "ȸ�������� �Ϸ�Ǿ����ϴ�.");
		} else if (e.getSource() == cancelBtn) {
			new Admin();
			f.dispose();
		}
	}

	private void select() {
		String sqlSelect = "SELECT * FROM MemberTBL ORDER BY userName ASC";

		try {
			MemberDAO dao = new MemberDAO();
			dao.DBConnection();
			con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
			ps = con.prepareStatement(sqlSelect);
			rs = ps.executeQuery();

			while (rs.next()) {
				model.addRow(new Object[] { rs.getString("userId"), rs.getString("userPw"), rs.getString("userName"),
						rs.getString("userBirth"), rs.getString("userEmail"), rs.getString("userTel"),
						rs.getString("userAddr") });
			}
		} catch (Exception e) {
			System.out.println("�������� ����");
		} finally {
			try {
				rs.close();
				ps.close();
				con.close();
			} catch (Exception e) {
				System.out.println("���� ����");
			}
		}
	}

	public boolean deleteMember() {
		boolean check = false;

		DefaultTableModel model2 = (DefaultTableModel) table.getModel();
		int row = table.getSelectedRow();

		try {
			MemberDAO dao = new MemberDAO();
			con = dao.DBConnection();

			String sqlDelete = "DELETE FROM memberTBL WHERE userTel = ?";

			ps = con.prepareStatement(sqlDelete);
			ps.setString(1, (String) model2.getValueAt(row, 5));
			int rs1 = ps.executeUpdate();

			if (rs1 > 0) {
				System.out.println("���� ����");
				check = true;
			} else
				System.out.println("���� ����");
		} catch (Exception ee) {
			System.out.println("���� ��¥ ����");
		}
		model2.setRowCount(0);
		select();
		return check;
	}

	private class JTableMouseListener implements MouseListener {
		public void mouseClicked(java.awt.event.MouseEvent e) {
			JTable jtable = (JTable) e.getSource();
			int row = jtable.getSelectedRow();
			int col = jtable.getSelectedColumn();

			System.out.println(model.getValueAt(row, col));
		}

		@Override
		public void mousePressed(MouseEvent e) {
		}

		@Override
		public void mouseReleased(MouseEvent e) {
		}

		@Override
		public void mouseEntered(MouseEvent e) {
		}

		@Override
		public void mouseExited(MouseEvent e) {
		}
	}
}