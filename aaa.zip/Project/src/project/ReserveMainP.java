package project;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class ReserveMainP extends JFrame implements ActionListener {
	private JFrame frame;
	private JPanel reserveMainPanel;
	private JButton reserveBtn;
	private JButton checkBtn;
	
	public String s_tel;

	public ReserveMainP() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("�װ��� ���� �� ��ȸ");
		frame.setBounds(100, 100, 800, 600);
		frame.setResizable(false);
		frame.setLocationRelativeTo(null);
		frame.getContentPane().setLayout(null);
		frame.setVisible(true);

		JPanel reserveMainPanel = new JPanel();
		reserveMainPanel.setBounds(0, 0, 794, 571);
		frame.getContentPane().add(reserveMainPanel);
		reserveMainPanel.setLayout(null);

		reserveBtn = new JButton("�װ��� ���� �ϱ�");
		reserveBtn.setBounds(109, 62, 535, 141);
		reserveMainPanel.add(reserveBtn);

		checkBtn = new JButton("�װ��� ���� Ȯ��");
		checkBtn.setBounds(109, 301, 535, 141);
		reserveMainPanel.add(checkBtn);

		reserveBtn.addActionListener(this);
		checkBtn.addActionListener(this);

	}
	
	

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == reserveBtn) {
			new ReservePage();
			frame.dispose();
		} else if (e.getSource() == checkBtn) {
			new Confirm_reserve();
			frame.dispose();
		}
	}
}