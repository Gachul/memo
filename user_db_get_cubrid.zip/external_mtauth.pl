#!/usr/bin/perl 
use vars qw(%RAD_REQUEST %RAD_REPLY %RAD_CHECK);

        use constant    PPX_MODULE_REJECT=>    0;#  /* immediately reject the request */
        use constant    PPX_MODULE_FAIL=>      1;#  /* module failed, don't reply */
        use constant    PPX_MODULE_OK=>        2;#  /* the module is OK, continue */
        use constant    PPX_MODULE_HANDLED=>   3;#  /* the module handled the request, so stop. */
        use constant    PPX_MODULE_INVALID=>   4;#  /* the module considers the request invalid. */
        use constant    PPX_MODULE_USERLOCK=>  5;#  /* reject the request (user is locked out) */
        use constant    PPX_MODULE_NOTFOUND=>  6;#  /* user not found */
        use constant    PPX_MODULE_NOOP=>      7;#  /* module succeeded without doing anything */
        use constant    PPX_MODULE_UPDATED=>   8;#  /* OK (pairs modified) */
        use constant    PPX_MODULE_NUMCODES=>  9;#  /* How many return codes there are */

use DBI;
use Time::Local;
use Digest::MD5 qw(md5_hex);

sub post_auth {
        $RAD_REQUEST{'User-Name'}=~s/[^0-9A-z@._:-]//g;

        $database = "radius";
        $user = "entro";
        $password = "dnflskfk_ppx_2000";
        $option = "localhost";

        $dsn = "DBI:mysql:$database";
        $dsn = "DBI:mysql:database=$database;$option";
        $dbh = DBI->connect($dsn, $user, $password);

        my $sql = $dbh->prepare( "SELECT count, usemacauth, usestaticip, limitnas, limitssid, passlimit, limitweek, limitexpiration, limituptime, limitdl, limitul, comment, passlock FROM mt_users, mt_profiles WHERE mt_users.UserName='$RAD_REQUEST{'User-Name'}' and mt_users.profid=mt_profiles.profid");
        $rowcount = $sql->execute
        or die "Cannot execute SQL statement: $DBI::errstr\n";

        my @row = $sql->fetchrow;
        my $count_p = $row[0];
        my $usemacauth = $row[1];
        my $usestaticip = $row[2];
        my $limitnas = $row[3];
        my $limitssid = $row[4];
        my $passlimit = $row[5];
        my $limitweek = $row[6];
        my $limitexpiration = $row[7];
        my $limituptime = $row[8];
        my $limitdl = $row[9];
        my $limitul = $row[10];
        my $nolock = $row[11];
        my $passlock = $row[12];

	my $count_m = $count_p + 1;

	if($passlock == '1'){

		if($count_m > '5'){
			$RAD_REPLY{'Reply-Message'} = "Disabled User" ;
		}else{
	                if(($usemacauth != '1')&&($usestaticip != '1')&&($limitna != '1')&&($limitssid != '1')&&($limitweek != '1')&&($limitexpiration != '1')&&($limituptime != '1')&&($limitdl != '1')&&($limitul != '1')&&($nolock ne 'UNLOCK')){
			        $RAD_REPLY{'Reply-Message'} = "Disable Count $count_m/5";
                		my $sql = $dbh->prepare( "INSERT into radpostauth(id, user, reply, CallingStationId, NASIPAddress, CalledStationId, NASPort, NASPortType, date, time,unix_time) values ('', '$RAD_REQUEST{'User-Name'}', 'Disable Count $count_m/5 ', '$RAD_REQUEST{'Calling-Station-Id'}', '$RAD_REQUEST{'NAS-IP-Address'}', '$RAD_REQUEST{'Called-Station-id'}', '$RAD_REQUEST{'NAS-Port'}', '$RAD_REQUEST{'NAS-Port-Type'}',NOW(), curtime(),unix_timestamp(now()))");
		                $rowcount = $sql->execute
	        	        or die "Cannot execute SQL statement: $DBI::errstr\n";

	                        my $sql = $dbh->prepare( "UPDATE mt_users SET count= ($count_p + 1)  WHERE UserName ='$RAD_REQUEST{'User-Name'}'");
	                        $rowcount = $sql->execute
        	                or die "Cannot execute SQL statement: $DBI::errstr\n";
			}
		}
	        return PPX_MODULE_REJECT;
	}	
}

sub authorize {

        $RAD_REQUEST{'User-Name'}=~s/[^0-9A-z@._:-]//g;

        $database = "radius";
        $user = "entro";
        $password = "dnflskfk_ppx_2000";
        $option = "localhost";

        $dsn = "DBI:mysql:$database";
        $dsn = "DBI:mysql:database=$database;$option";
        $dbh = DBI->connect($dsn, $user, $password);

        my $sql = $dbh->prepare( "DELETE from mt_users WHERE UserName ='$RAD_REQUEST{'User-Name'}' and profid ='0'");
        $rowcount = $sql->execute
        or die "Cannot execute SQL statement: $DBI::errstr\n";

        my $sql = $dbh->prepare( "SELECT count(*) as auth_check from mt_users where UserName ='$RAD_REQUEST{'User-Name'}'");
        $rowcount = $sql->execute
        or die "Cannot execute SQL statement: $DBI::errstr\n";
        my @row = $sql->fetchrow;
        my $auth_check = $row[0];
 
if($auth_check == "0"){
        my $sql = $dbh->prepare( "DELETE from mt_users WHERE UserName ='$RAD_REQUEST{'User-Name'}' and profid ='3'");
        $rowcount = $sql->execute
        or die "Cannot execute SQL statement: $DBI::errstr\n";

        my $sql = $dbh->prepare("insert into mt_users (UserName,password,station,realname,subject,createdon,expiration,uplimit,downlimit,uptimelimit,profid,web_password,passlock )
        values('$RAD_REQUEST{'User-Name'}',HEX(AES_ENCRYPT('','$RAD_REQUEST{'User-Name'}')),'NO','$RAD_REQUEST{'User-Name'}','NO',NOW(),NOW(),'0','0','0','3',HEX(AES_ENCRYPT('','$RAD_REQUEST{'User-Name'}')),'')");
        $rowcount = $sql->execute
        or die "Cannot execute SQL statement: $DBI::errstr\n";
}

        my $sql = $dbh->prepare( "SELECT enableuser, downlimit, uplimit, expiration, uptimelimit, usemacauth, mt_users.profid, staticip, usestaticip, tprofid, first_conn_date, first_conn_time, mac, downrate, uprate,limitdl, 
limitul,limitexpiration, limituptime, limitweek, limitnas, mt_users.nas_group_name, framedip, simuse, mt_profiles.profname, authid, passlimit, UNIX_TIMESTAMP(passchangdate), UNIX_TIMESTAMP(NOW()) as today, passlock, mac2, mac3, 
mac4, mac5, limitssid, mt_users.ssid_group_name,mac6,mac7,mac8,mac9,mac10,otpuse, otpsecret, otppin, otptimezone,otpduration, from_unixtime(unix_timestamp(now()) + otp_timeoffset) as otptime, question, count, limitmacg, 
mt_users.mac_group_name, mt_users.otpbase32,mt_users.otphmac FROM mt_users, mt_profiles WHERE mt_users.UserName ='$RAD_REQUEST{'User-Name'}' and mt_users.profid=mt_profiles.profid");

        $rowcount = $sql->execute
        or die "Cannot execute SQL statement: $DBI::errstr\n";

        my @row = $sql->fetchrow;

		my $enableuser = $row[0];
                my $downlimit = $row[1];
                my $uplimit = $row[2];
                my $expiration = $row[3];
                my $uptimelimit = $row[4];
                my $usemacauth = $row[5];
                my $profid = $row[6];
                my $staticip = $row[7];
                my $usestaticip = $row[8];
                my $tprofid = $row[9];
                my $first_conn_date = $row[10];
                my $first_conn_time = $row[11];
                my $mac = $row[12];
                my $downrate = $row[13];
                my $uprate = $row[14];
                my $limitdl = $row[15];
                my $limitul = $row[16];
                my $limitexpiration = $row[17];
                my $limituptime = $row[18];
                my $limitweek = $row[19];
                my $limitnas = $row[20];
		my $nas_group_name = $row[21];
		my $framedip = $row[22];
                my $simuse= $row[23];
                my $profname= $row[24];
                my $authid= $row[25];
                my $passlimit= $row[26] * 86400;
                my $passchangdate= $row[27];
                my $today= $row[28];
                my $passlock= $row[29];
                my $mac2 = $row[30];
                my $mac3 = $row[31];
                my $mac4 = $row[32];
                my $mac5 = $row[33];
                my $limitssid = $row[34];
                my $ssid_group_name = $row[35];
                my $mac6 = $row[36];
                my $mac7 = $row[37];
                my $mac8 = $row[38];
                my $mac9 = $row[39];
                my $mac10 = $row[40];
                my $otp_use = $row[41];
                my $otp_secret = $row[42];
                my $otp_pin = $row[43];
                my $otp_timezone = $row[44];
                my $otp_duration = $row[45];
                my $otp_time = $row[46];
                my $check_drop = $row[47];
                my $count_c = $row[48];
                my $limitmac = $row[49];
                my $mac_group_name = $row[50];
                my $otpbase32 = $row[51];
                my $otphmac = $row[52];


## POTP ##
                if ( $otp_use == "1" )
                {
                        if($otpbase32 == "1"){
                                $otpbase32_b = "-b";
                        }else{
                                $otpbase32_b = "";
                        }

                $otp = `oathtool --totp=$otphmac $otpbase32_b --time-step-size=$otp_duration --digits=$otp_pin --now='$otp_time UTC$otp_timezone' $otp_secret`;
                $otp =~s/[^0-9]//g;

                        my $sql = $dbh->prepare( "UPDATE mt_users SET password = HEX(AES_ENCRYPT('$otp','$RAD_REQUEST{'User-Name'}'))  WHERE UserName ='$RAD_REQUEST{'User-Name'}'");
                        $rowcount = $sql->execute
                        or die "Cannot execute SQL statement: $DBI::errstr\n";

                }

#######Password_Lock_Time#####################
#
#
#		if ($check_drop eq 'D'){
#                                $RAD_REPLY{'Reply-Message'} = "Drop User" ;
#                                my $sql = $dbh->prepare( "INSERT into radpostauth(id, user, reply, CallingStationId, NASIPAddress, CalledStationId, NASPort, NASPortType, date, time,unix_time) values ('', '$RAD_REQUEST{'User-Name'}', 'Drop User', '$RAD_REQUEST{'Calling-Station-Id'}', '$RAD_REQUEST{'NAS-IP-Address'}', '$RAD_REQUEST{'Called-Station-id'}', '$RAD_REQUEST{'NAS-Port'}', '$RAD_REQUEST{'NAS-Port-Type'}',NOW(), curtime(),unix_timestamp(now()))");
#                                $rowcount = $sql->execute
#                                or die "Cannot execute SQL statement: $DBI::errstr\n";
#
#			return PPX_MODULE_REJECT;
#		}
#
#############################################

#######Password_Lock_check#####################
                if($count_c >= "5")
                {
                	my $sql = $dbh->prepare( "INSERT into radpostauth(id, user, reply, CallingStationId, NASIPAddress, CalledStationId, NASPort, NASPortType, date, time,unix_time) values ('', '$RAD_REQUEST{'User-Name'}', 'Disable user', '$RAD_REQUEST{'Calling-Station-Id'}', '$RAD_REQUEST{'NAS-IP-Address'}', '$RAD_REQUEST{'Called-Station-id'}', '$RAD_REQUEST{'NAS-Port'}', '$RAD_REQUEST{'NAS-Port-Type'}',NOW(), curtime(),unix_timestamp(now()))");
                        $rowcount = $sql->execute
                        or die "Cannot execute SQL statement: $DBI::errstr\n";

                        my $sql = $dbh->prepare( "UPDATE mt_users set enableuser='0' WHERE UserName='$RAD_REQUEST{'User-Name'}'");
                        $rowcount = $sql->execute
                        or die "Cannot execute SQL statement: $DBI::errstr\n";

			$RAD_REPLY{'Reply-Message'} = "Disable user" ;
                        return PPX_MODULE_REJECT;
                 }
#############################################

#######TEST_TIME_LIMIT########################
#                my $sql_ck = $dbh->prepare( "SELECT unix_timestamp(comment),unix_timestamp(now()) FROM mt_users WHERE UserName='$RAD_REQUEST{'User-Name'}'");
#                $rowcount_ck = $sql_ck->execute
#                or die "Cannot execute SQL statement: $DBI::errstr\n";
#
#                my @row_ck = $sql_ck->fetchrow;
#
#                my $limit_date_D = $row_ck[0];
#                my $now_date_D = $row_ck[1];
#
#                if($limit_date_D < $now_date_D){
#                my $sql = $dbh->prepare("delete from mt_users WHERE UserName='$RAD_REQUEST{'User-Name'}'");
#                $rowcount = $sql->execute
#                or die "Cannot execute SQL statement: $DBI::errstr\n";
#                }
#############################################################################################

## VAS ##

        my $sql_ad = $dbh->prepare( "SELECT mt_profiles.profname, count(*) as ad_cnt FROM mt_ad_users, mt_profiles WHERE mt_ad_users.UserName ='$RAD_REQUEST{'User-Name'}' and mt_ad_users.profid=mt_profiles.profid");
        $rowcount_ad = $sql_ad->execute;
        my @row_ad = $sql_ad->fetchrow;

                my $profname_ad = $row_ad[0];
                my $ad_cnt = $row_ad[1];

		if($ad_cnt != "0"){
                	my $sql_adp = $dbh->prepare( "SELECT Attribute,Value FROM radgroupreply WHERE GroupName='$profname_ad'" );
			$rowcount_adp = $sql_adp->execute
                        or die "Cannot execute SQL statement: $DBI::errstr\n";

        	        my @row_adp;
	
	                while ( @row_adp = $sql_adp->fetchrow_array() )
                	{
        	                my $att = $row_adp[0];
	                        my $value = $row_adp[1];
                        	$RAD_REPLY{$att} = "$value";
			}
		}
	
                my $sqla = $dbh->prepare( "SELECT Attribute,Value FROM radgroupreply WHERE GroupName='$profname'" );
	                $rowcounta = $sqla->execute
                        or die "Cannot execute SQL statement: $DBI::errstr\n";

                my @rowa;

                while ( @rowa = $sqla->fetchrow_array() )
                {
	                my $att = $rowa[0];
                        my $value = $rowa[1];
                        $RAD_REPLY{$att} = "$value";
                 }
####

                if ( $rowcount != "1" )
                {
 #                       $RAD_REPLY{'Reply-Message'} = "User ID not found";

 #                       my $sql = $dbh->prepare( "INSERT into radpostauth(id, user, reply, CallingStationId, NASIPAddress, CalledStationId, NASPort, NASPortType, date, time,unix_time) values ('', '$RAD_REQUEST{'User-Name'}','User ID not found', '$RAD_REQUEST{'Calling-Station-Id'}', '$RAD_REQUEST{'NAS-IP-Address'}', '$RAD_REQUEST{'Called-Station-id'}', '$RAD_REQUEST{'NAS-Port'}', '$RAD_REQUEST{'NAS-Port-Type'}',NOW(),curtime()");
 #                       $rowcount = $sql->execute
 #                       or die "Cannot execute SQL statement: $DBI::errstr\n";
                        return PPX_MODULE_NOTFOUND;
 #			#return PPX_MODULE_REJECT;
               }


                if($RAD_REQUEST{'User-Name'} =~ /@/i){

                }else{

		if ( $enableuser != "1" ) 
			{

			$RAD_REPLY{'Reply-Message'} = "Account is not enable";
                        my $sql = $dbh->prepare( "INSERT into radpostauth(id, user, reply, CallingStationId, NASIPAddress, CalledStationId, NASPort, NASPortType, date, time,unix_time) values ('',  '$RAD_REQUEST{'User-Name'}','Account is not enable', '$RAD_REQUEST{'Calling-Station-Id'}', '$RAD_REQUEST{'NAS-IP-Address'}', '$RAD_REQUEST{'Called-Station-id'}', '$RAD_REQUEST{'NAS-Port'}', '$RAD_REQUEST{'NAS-Port-Type'}',NOW(), curtime(),unix_timestamp(now()))");
                        $rowcount = $sql->execute
                        or die "Cannot execute SQL statement: $DBI::errstr\n";
		        return PPX_MODULE_REJECT;
			}
		}
		
		if ( $usemacauth == "1" ) 
			{
			$rmac=$RAD_REQUEST{'Calling-Station-Id'};
			$rmac=~s/[^0-9A-z]//g;
                        $rmac=~tr/A-Z/a-z/;
			
			if (( "$rmac" ne "$mac" )&&( "$rmac" ne "$mac2" )&&( "$rmac" ne "$mac3" )&&( "$rmac" ne "$mac4" )&&( "$rmac" ne "$mac5")&&( "$rmac" ne "$mac6")&&( "$rmac" ne "$mac7")&&( "$rmac" ne "$mac8")&&( "$rmac" ne "$mac9")&&( "$rmac" ne "$mac10"))
				{
	
	 			if ($RAD_REQUEST{'Calling-Station-Id'} ne "")
					{
			       	        	$RAD_REPLY{'Reply-Message'} = "Diff assign MAC" ;
      				                my $sql = $dbh->prepare( "INSERT into radpostauth(id, user, reply, CallingStationId, NASIPAddress, CalledStationId, NASPort, NASPortType, date, time,unix_time) values ('', '$RAD_REQUEST{'User-Name'}', 'Diff assign MAC', '$RAD_REQUEST{'Calling-Station-Id'}', '$RAD_REQUEST{'NAS-IP-Address'}', '$RAD_REQUEST{'Called-Station-id'}', '$RAD_REQUEST{'NAS-Port'}', '$RAD_REQUEST{'NAS-Port-Type'}',NOW(), curtime(),unix_timestamp(now()))");
               				        $rowcount = $sql->execute
                       				or die "Cannot execute SQL statement: $DBI::errstr\n";
						return PPX_MODULE_REJECT;
			        	}
				}
			}

		if ( $usestaticip == "1" )
			{
			$rstaticip=$RAD_REQUEST{'Framed-IP-Address'};
                        $rstaticip=~s/[^0-9A-z]//g;
			$staticip=~s/[^0-9A-z]//g;

                        if ( "$rstaticip" ne "$staticip" )
                                {
                                $RAD_REPLY{'Reply-Message'} = "Diff assign IP" ;
                                my $sql = $dbh->prepare( "INSERT into radpostauth(id, user, reply, CallingStationId, NASIPAddress, CalledStationId, NASPort, NASPortType, date, time,unix_time) values ('', '$RAD_REQUEST{'User-Name'}', 'Diff assign IP', '$RAD_REQUEST{'Calling-Station-Id'}', '$RAD_REQUEST{'NAS-IP-Address'}', '$RAD_REQUEST{'Called-Station-id'}', '$RAD_REQUEST{'NAS-Port'}', '$RAD_REQUEST{'NAS-Port-Type'}',NOW(), curtime(),unix_timestamp(now()))");
                                $rowcount = $sql->execute
                                or die "Cannot execute SQL statement: $DBI::errstr\n";
                                return PPX_MODULE_REJECT;
				}
			}
## Simultaneous-Use ACL  ##

                if ( $simuse != "0" )
                        {

                        my $sqls = $dbh->prepare( "SELECT count(*) FROM radacct WHERE UserName='$RAD_REQUEST{'User-Name'}' and AcctStopTime ='0000-00-00 00:00:00'" );


                        $rowcount = $sqls->execute
                        or die "Cannot execute SQL statement: $DBI::errstr\n";
			
			my @row = $sqls->fetchrow;
			my $simusecount = $row[0] + 1 ;

                                if($simuse < $simusecount )
                                        {
                                        $RAD_REPLY{'Reply-Message'} = "Simultaneous-Use Over" ;
                                        my $sql = $dbh->prepare( "INSERT into radpostauth(id, user, reply, CallingStationId, NASIPAddress, CalledStationId, NASPort, NASPortType, date, time,unix_time) values ('',  '$RAD_REQUEST{'User-Name'}', 'Simultaneous-Use Over', '$RAD_REQUEST{'Calling-Station-Id'}', '$RAD_REQUEST{'NAS-IP-Address'}', '$RAD_REQUEST{'Called-Station-id'}', '$RAD_REQUEST{'NAS-Port'}', '$RAD_REQUEST{'NAS-Port-Type'}',NOW(), curtime(),unix_timestamp(now()))");
                                        $rowcount = $sql->execute
                                        or die "Cannot execute SQL statement: $DBI::errstr\n";
                                        return PPX_MODULE_REJECT;
                                        }
                        }

## NAS Group Base ACL ##
                if ( $limitnas == "1" )
                        {

			my $sqln = $dbh->prepare( "SELECT count(*) as rowcountn FROM nas_group_policy WHERE nas_group_policy.nas_group_name='$nas_group_name' and nasname='$RAD_REQUEST{'NAS-IP-Address'}'" );

		        $rowcountn = $sqln->execute
		        or die "Cannot execute SQL statement: $DBI::errstr\n";


		        my @rown;

		        while ( @rown = $sqln->fetchrow_array() )
			        {
                		my $rowcountc = $rown[0];
			
	                        if($rowcountc == "0" )
       		                        {
               		                $RAD_REPLY{'Reply-Message'} = "Wrong NAS(AP) Group" ;
                   	                my $sql = $dbh->prepare( "INSERT into radpostauth(id, user, reply, CallingStationId, NASIPAddress, CalledStationId, NASPort, NASPortType, date, time,unix_time) values ('', '$RAD_REQUEST{'User-Name'}', 'Wrong NAS(AP) Group', '$RAD_REQUEST{'Calling-Station-Id'}', '$RAD_REQUEST{'NAS-IP-Address'}', '$RAD_REQUEST{'Called-Station-id'}', '$RAD_REQUEST{'NAS-Port'}', '$RAD_REQUEST{'NAS-Port-Type'}',NOW(),  curtime(),unix_timestamp(now()))");
	                                $rowcount = $sql->execute
        	                        or die "Cannot execute SQL statement: $DBI::errstr\n";
                       		        return PPX_MODULE_REJECT;
                               		}
				}
			}

## NAS Group Base SSID ##
                if ( $limitssid == "1" )
                        {

                        $ssid = substr $RAD_REQUEST{'Called-Station-Id'} ,19;

                        if($ssid eq ""){
                                $ssid = $RAD_REQUEST{'Aruba-Essid-Name'};
                        }

                        my $sqln = $dbh->prepare( "SELECT count(*) as rowcountn FROM ssid_group_policy WHERE ssid_group_policy.ssid_group_name='$ssid_group_name' and ssid like '%$ssid%'");

                        $rowcountn = $sqln->execute
                        or die "Cannot execute SQL statement: $DBI::errstr\n";

                        my @rown;
                        while ( @rown = $sqln->fetchrow_array() )
                                {
                                my $rowcountc = $rown[0];
        	                        if($rowcountc == "0" )
	                                        {
                	                        $RAD_REPLY{'Reply-Message'} = "Wrong SSID(AP) Group" ;
                         	                my $sql = $dbh->prepare( "INSERT into radpostauth(id, user, reply, CallingStationId, NASIPAddress, CalledStationId, NASPort, NASPortType, date, time,unix_time) values ('','$RAD_REQUEST{'User-Name'}', 'Wrong SSID(AP) Group', '$RAD_REQUEST{'Calling-Station-Id'}', '$RAD_REQUEST{'NAS-IP-Address'}', '$RAD_REQUEST{'Called-Station-id'}', '$RAD_REQUEST{'NAS-Port'}', '$RAD_REQUEST{'NAS-Port-Type'}',NOW(),  curtime(),unix_timestamp(now()))");
	                                        $rowcount = $sql->execute
        	                                or die "Cannot execute SQL statement: $DBI::errstr\n";
                	                        return PPX_MODULE_REJECT;
                        	                }
                                }
                        }


## NAC MAC Group Base ACL ##
                if ( $limitmac == "1" )
                        {


                        $nmac = substr $RAD_REQUEST{'Called-Station-Id'} ,0, 17;
                        $nmac=~s/[^0-9A-z]//g;

                        my $sqln = $dbh->prepare( "SELECT count(*) as rowcountn FROM mac_group_policy WHERE mac_group_policy.mac_group_name='$mac_group_name' and mac='$nmac'" );

                        $rowcountn = $sqln->execute
                        or die "Cannot execute SQL statement: $DBI::errstr\n";

                        my @rown;

                        while ( @rown = $sqln->fetchrow_array() )
                                {
                                my $rowcountc = $rown[0];

                                if($rowcountc == "0" )
                                        {
                                        $RAD_REPLY{'Reply-Message'} = "Wrong NAS(MAC) Group" ;

                                        my $sql = $dbh->prepare( "INSERT into radpostauth(id, user, reply, CallingStationId, NASIPAddress, CalledStationId, NASPort, NASPortType, date, time,unix_time) values ('','$RAD_REQUEST{'User-Name'}', 'Wrong NAS(MAC) Group', '$RAD_REQUEST{'Calling-Station-Id'}', '$RAD_REQUEST{'NAS-IP-Address'}', '$RAD_REQUEST{'Called-Station-id'}', '$RAD_REQUEST{'NAS-Port'}','$RAD_REQUEST{'NAS-Port-Type'}',NOW(),  curtime(),unix_timestamp(now()))");
                                        $rowcount = $sql->execute
                                        or die "Cannot execute SQL statement: $DBI::errstr\n";
                                        return PPX_MODULE_REJECT;
                                        }
                                }
                        }


## Password Limit ACL ##
                if ( $passlimit != "0" )
                        {
			

			$limitpassword = $today - $passchangdate;

                                if($passlimit <= $limitpassword )
                                        {
                                        $RAD_REPLY{'Reply-Message'} = "Password change day expired" ;
                                        my $sql = $dbh->prepare( "INSERT into radpostauth(id, user, reply, CallingStationId, NASIPAddress, CalledStationId, NASPort, NASPortType, date, time,unix_time) values ('','$RAD_REQUEST{'User-Name'}', 'Password change day expired', '$RAD_REQUEST{'Calling-Station-Id'}', '$RAD_REQUEST{'NAS-IP-Address'}','$RAD_REQUEST{'Called-Station-id'}', '$RAD_REQUEST{'NAS-Port'}', '$RAD_REQUEST{'NAS-Port-Type'}',NOW(), curtime(),unix_timestamp(now()))");
                                        $rowcount = $sql->execute
                                        or die "Cannot execute SQL statement: $DBI::errstr\n";
                                        return PPX_MODULE_REJECT;
                                        }
                        }

## Week Base ACL##
               if ( $limitweek == "1" )
                        {

			my ($sec, $min, $hour) = localtime;
			my @week = qw( sun mon tue wed thu fri sat );
			my $wk = $week[(localtime)[6]];

                        my $sqlw = $dbh->prepare( "SELECT substr($wk,$hour+1,1) FROM time_control_policy WHERE profid=$tprofid" );

                        $rowcountw = $sqlw->execute
                        or die "Cannot execute SQL statement: $DBI::errstr\n";


                        my @roww;
	
                        while ( @roww = $sqlw->fetchrow_array() )
                                {
                                my $val = $roww[0];

				if ($val != "1")
					{
                                        $RAD_REPLY{'Reply-Message'} = "Not auth time" ;
                	                my $sql = $dbh->prepare( "INSERT into radpostauth(id, user, reply, CallingStationId, NASIPAddress, CalledStationId, NASPort, NASPortType, date, time,unix_time) values ('', '$RAD_REQUEST{'User-Name'}', 'Not auth time', '$RAD_REQUEST{'Calling-Station-Id'}', '$RAD_REQUEST{'NAS-IP-Address'}', '$RAD_REQUEST{'Called-Station-id'}', '$RAD_REQUEST{'NAS-Port'}', '$RAD_REQUEST{'NAS-Port-Type'}',NOW(), curtime(),unix_timestamp(now()))");
	                                $rowcount = $sql->execute
        	                        or die "Cannot execute SQL statement: $DBI::errstr\n";
                                        return PPX_MODULE_REJECT;
                                        }
                                }
                        }


## START Date ACL ##

                if ( $limitexpiration == "1" )
                        {

                        my $sql = $dbh->prepare( "SELECT count(*) as start_cnt FROM mt_users where unix_timestamp(start_datetime) > unix_timestamp(now()) and UserName ='$RAD_REQUEST{'User-Name'}'");

                        $rowcount = $sql->execute
                        or die "Cannot execute SQL statement: $DBI::errstr\n";
                        my @row;
                        while ( @row = $sql->fetchrow_array() )
                        {

                                if ($row[0] == "1")
                                        {
                                        $RAD_REPLY{'Reply-Message'} = "Account is start date Limit" ;
                                        my $sql = $dbh->prepare( "INSERT into radpostauth(id, user, reply, CallingStationId, NASIPAddress, CalledStationId, NASPort, NASPortType, date, time,unix_time) values ('','$RAD_REQUEST{'User-Name'}', 'Account is start date Limit', '$RAD_REQUEST{'Calling-Station-Id'}', '$RAD_REQUEST{'NAS-IP-Address'}', '$RAD_REQUEST{'Called-Station-id'}', '$RAD_REQUEST{'NAS-Port'}', '$RAD_REQUEST{'NAS-Port-Type'}',NOW(), curtime(),unix_timestamp(now()))");
                                        $rowcount = $sql->execute
                                        or die "Cannot execute SQL statement: $DBI::errstr\n";
                                        return PPX_MODULE_REJECT;
                                        }
                                }
                        }



## EXP Date ACL ##

                if ( $limitexpiration == "1" )
                        {

		        my $sql = $dbh->prepare( "SELECT count(*) as exp_cnt FROM mt_users where unix_timestamp(now()) > unix_timestamp(expiration) and UserName ='$RAD_REQUEST{'User-Name'}'");

		        $rowcount = $sql->execute
		        or die "Cannot execute SQL statement: $DBI::errstr\n";
		        my @row;
		        while ( @row = $sql->fetchrow_array() )
		        {

				if ($row[0] == "1")
	                		{
                                	$RAD_REPLY{'Reply-Message'} = "Account is expired" ;
                  	                my $sql = $dbh->prepare( "INSERT into radpostauth(id, user, reply, CallingStationId, NASIPAddress, CalledStationId, NASPort, NASPortType, date, time,unix_time) values ('', '$RAD_REQUEST{'User-Name'}', 'Account is expired', '$RAD_REQUEST{'Calling-Station-Id'}', '$RAD_REQUEST{'NAS-IP-Address'}', '$RAD_REQUEST{'Called-Station-id'}', '$RAD_REQUEST{'NAS-Port'}', '$RAD_REQUEST{'NAS-Port-Type'}',NOW(), curtime(),unix_timestamp(now()))");
 	                                $rowcount = $sql->execute
        	                        or die "Cannot execute SQL statement: $DBI::errstr\n";
	                                return PPX_MODULE_REJECT;
        	                        }
                	        }
			}



## Time Base ACL
                if ( $limituptime == "1" )
                        {

                        my $sql = $dbh->prepare( "SELECT SUM(AcctSessionTime) FROM radacct WHERE UserName='$RAD_REQUEST{'User-Name'}'");

                        $rowcount = $sql->execute
                        or die "Cannot execute SQL statement: $DBI::errstr\n";
                        my @row;
                        while ( @row = $sql->fetchrow_array() )
                        {

                        $acctsesstime  = $uptimelimit - $row[0];
                        $mt_timeout = 0;

			$mt_timeout = $acctsesstime;

                                if ($mt_timeout <= "0")
                                        {
	                                        $RAD_REPLY{'Reply-Message'} = "No more online time left" ;
        	        	                my $sql = $dbh->prepare( "INSERT into radpostauth(id, user, reply, CallingStationId, NASIPAddress, CalledStationId, NASPort, NASPortType, date, time,unix_time) values ('', '$RAD_REQUEST{'User-Name'}', 'No more online time left', '$RAD_REQUEST{'Calling-Station-Id'}', '$RAD_REQUEST{'NAS-IP-Address'}', '$RAD_REQUEST{'Called-Station-id'}', '$RAD_REQUEST{'NAS-Port'}', '$RAD_REQUEST{'NAS-Port-Type'}',NOW(), curtime(),unix_timestamp(now()))");
	        	                        $rowcount = $sql->execute
        	        	                or die "Cannot execute SQL statement: $DBI::errstr\n";
                                	        return PPX_MODULE_REJECT;
                                        }
					else
					{
						$RAD_REPLY{'Session-Timeout'} = "$mt_timeout";

				        }
				}
                        }

## Download Base ACL##
                if ( $limitdl == "1" )
                        {


                        my $sql = $dbh->prepare( "SELECT SUM(AcctOutputOctets) FROM radacct WHERE UserName='$RAD_REQUEST{'User-Name'}'");

                        $rowcount = $sql->execute
                        or die "Cannot execute SQL statement: $DBI::errstr\n";
                        my @row;
                        while ( @row = $sql->fetchrow_array() )
        	                {

                	        $mt_xmit_limit = $downlimit - $row[0];

				if ($mt_xmit_limit <= "0")
                                        {
                                        $RAD_REPLY{'Reply-Message'} = "Download limit reached" ;
                       		        my $sql = $dbh->prepare( "INSERT into radpostauth(id, user, reply, CallingStationId, NASIPAddress, CalledStationId, NASPort, NASPortType, date, time,unix_time) values ('', '$RAD_REQUEST{'User-Name'}', 'Download limit reached', '$RAD_REQUEST{'Calling-Station-Id'}', '$RAD_REQUEST{'NAS-IP-Address'}', '$RAD_REQUEST{'Called-Station-id'}', '$RAD_REQUEST{'NAS-Port'}', '$RAD_REQUEST{'NAS-Port-Type'}',NOW(), curtime(),unix_timestamp(now()))");
	                                $rowcount = $sql->execute
        	                        or die "Cannot execute SQL statement: $DBI::errstr\n";
                                        return PPX_MODULE_REJECT;
                                        }
				else
					{
					$RAD_REPLY{'PPX-Xmit-Limit'} = "$mt_xmit_limit" ;
					}
                                }
                        }

## Upload Base ACL ##
                if ( $limitul == "1" )
                        {


                        my $sql = $dbh->prepare( "SELECT SUM(AcctInputOctets) FROM radacct WHERE UserName='$RAD_REQUEST{'User-Name'}'");

                        $rowcount = $sql->execute
                        or die "Cannot execute SQL statement: $DBI::errstr\n";
                        my @row;
                        while ( @row = $sql->fetchrow_array() )
                        	{

	                        $mt_recv_limit = $uplimit - $row[0];

                                if ($mt_recv_limit <= "0")
                                        {
                                        $RAD_REPLY{'Reply-Message'} = "Upload limit reached" ;
	                                my $sql = $dbh->prepare( "INSERT into radpostauth(id, user, reply, CallingStationId, NASIPAddress, CalledStationId, NASPort, NASPortType, date, time,unix_time) values ('', '$RAD_REQUEST{'User-Name'}', 'Upload limit reached', '$RAD_REQUEST{'Calling-Station-Id'}', '$RAD_REQUEST{'NAS-IP-Address'}', '$RAD_REQUEST{'Called-Station-id'}', '$RAD_REQUEST{'NAS-Port'}', '$RAD_REQUEST{'NAS-Port-Type'}',NOW(), curtime(),unix_timestamp(now()))");
        	                        $rowcount = $sql->execute
                	                or die "Cannot execute SQL statement: $DBI::errstr\n";
                                        return PPX_MODULE_REJECT;
                                        }
                                else
                                        {
                                        $RAD_REPLY{'PPX-Recv-Limit'} = "$mt_recv_limit" ;
                                        }

                                }
                        }

			if ($first_conn_date == "NULL")
				{

				my $sql = $dbh->prepare( "UPDATE mt_users SET first_conn_date=curdate(), first_conn_time=curtime() WHERE UserName ='$RAD_REQUEST{'User-Name'}'");
	                        $rowcount = $sql->execute
        	                or die "Cannot execute SQL statement: $DBI::errstr\n";
				}

## EAP-Message-Auth-Type ##

                if ( $authid != "01" )
                        {
                        $auth_type = substr $RAD_REQUEST{'EAP-Message'},45,2;

			if($auth_type != "")
				{ 			
	                        $auth_type2 = substr $RAD_REQUEST{'EAP-Message'},10,2;
	                        if($authid != $auth_type2)
                		                {
		                                $RAD_REPLY{'Reply-Message'} = "Auth Type Not Match" ;
		                                my $sql = $dbh->prepare( "INSERT into radpostauth(id, user, reply, CallingStationId, NASIPAddress, CalledStationId, NASPort, NASPortType, date, time,unix_time) values ('', '$RAD_REQUEST{'User-Name'}', 'Auth Type Not Match', '$RAD_REQUEST{'Calling-Station-Id'}', '$RAD_REQUEST{'NAS-IP-Address'}', '$RAD_REQUEST{'Called-Station-id'}', '$RAD_REQUEST{'NAS-Port'}', '$RAD_REQUEST{'NAS-Port-Type'}',NOW(), curtime(),unix_timestamp(now()))");
		                                $rowcount = $sql->execute
                		                or die "Cannot execute SQL statement: $DBI::errstr\n";
		                                return PPX_MODULE_FAIL;
		                                }
                	        }
			}
##

## Framedip Assign ##
                if ( $framedip != "NULL" ){
                        $RAD_REPLY{'Framed-IP-Address'} = "$framedip" ;
                }
                else
                {
                        if(($RAD_REQUEST{'NAS-Identifier'} eq "AnyVPN-IPSEC") || ($RAD_REQUEST{'NAS-Identifier'} eq "AnyVPN-PPTP") || ($RAD_REQUEST{'NAS-Identifier'} eq "AnyVPN-SSL")){
                                my $sql = $dbh->prepare( "select ip1 from arp_allow,mt_users where device_type ='0' and arp_allow.status ='0' and poolname=pool_name and mt_users.UserName='$RAD_REQUEST{'User-Name'}' and UNIX_TIMESTAMP(arp_allow.timeupdate) < (UNIX_TIMESTAMP(now())-600) limit 1");
                                $rowcount = $sql->execute
                                or die "Cannot execute SQL statement: $DBI::errstr\n";

                                my @row = $sql->fetchrow;
                                my $ip1 = $row[0];

                                if($ip1 != ''){
                                        $RAD_REPLY{'Framed-IP-Address'} = "$ip1";

                                        my $sql = $dbh->prepare( "UPDATE arp_allow SET status='1', timeupdate=now() WHERE ip1 ='$ip1'");
                                        $rowcount = $sql->execute
                                        or die "Cannot execute SQL statement: $DBI::errstr\n";
                                }else{
                                        my $sql = $dbh->prepare( "select ip1 from arp_allow,mt_users,arp_pool where device_type ='0' and arp_allow.status ='0' and arp_pool.assign='$RAD_REQUEST{'NAS-Identifier'}' and arp_pool.poolname = arp_allow.poolname and UNIX_TIMESTAMP(arp_allow.timeupdate) < (UNIX_TIMESTAMP(now())-600) limit 1");
                                        $rowcount = $sql->execute
                                        or die "Cannot execute SQL statement: $DBI::errstr\n";

                                        my @row = $sql->fetchrow;
                                        my $ip1 = $row[0];

                                        if($ip1 != ''){
                                                $RAD_REPLY{'Framed-IP-Address'} = "$ip1";
                                                my $sql = $dbh->prepare( "UPDATE arp_allow SET status='1', timeupdate=now() WHERE ip1 ='$ip1'");
                                                $rowcount = $sql->execute
                                                or die "Cannot execute SQL statement: $DBI::errstr\n";
                                                }
                                }
                        }

                }

## Download Rate ACL ##
                if ( $downrate != "NULL" )
                        {
                        $RAD_REPLY{'Ascend-Data-Rate'} = "$downrate" ;
#                        $RAD_REPLY{'PPPD-Downstream-Speed-Limit'} = "$downrate" ;
                        }

## Upload Rate ACL ##
                if ( $uprate != "NULL" )
                        {
                        $RAD_REPLY{'Ascend-Xmit-Rate'} = "$uprate" ;
#                        $RAD_REPLY{'PPPD-Upstream-Speed-Limit'} = "$uprate" ;
                        }

        my $sql = $dbh->prepare( "SELECT reply FROM radpostauth WHERE user='$RAD_REQUEST{'User-Name'}' ORDER BY ID desc limit 1");
        $rowcount = $sql->execute
        or die "Cannot execute SQL statement: $DBI::errstr\n";

        my @row = $sql->fetchrow;
        my $reply = $row[0];

if($reply eq "Access-Accept"){

                $rmac=$RAD_REQUEST{'Calling-Station-Id'};
                $rmac=~s/[^0-9A-z]//g;
                $rmac=~tr/A-Z/a-z/;

		if($rmac ne ""){
			my $sql = $dbh->prepare( "update mt_users set registered_on = now(), count= '0', mac='$rmac' where UserName ='$RAD_REQUEST{'User-Name'}'");
			$rowcount = $sql->execute
			or die "Cannot execute SQL statement: $DBI::errstr\n";
		}
}
		return PPX_MODULE_OK;

}
#$sql->finish;
#$dbh->disconnect()
#or warn "Disconnection failed: $DBI::errstr\n";
#exit 1;

sub accounting {
        return PPX_MODULE_OK;
}
sub accounting_start{
        return PPX_MODULE_OK;

}
sub accounting_stop{

        $RAD_REQUEST{'User-Name'}=~s/[^0-9A-z@._:-]//g;

        $database = "radius";
        $user = "entro";
        $password = "dnflskfk_ppx_2000";
        $option = "localhost";

        $dsn = "DBI:mysql:$database";
        $dsn = "DBI:mysql:database=$database;$option";
        $dbh = DBI->connect($dsn, $user, $password);

        my $sql = $dbh->prepare( "update arp_allow set status='0', timeupdate=now() where ip1 = '$RAD_REQUEST{'Framed-IP-Address'}'");
        $rowcount = $sql->execute
        or die "Cannot execute SQL statement: $DBI::errstr\n";

        return PPX_MODULE_OK;
}
#exit 1;
