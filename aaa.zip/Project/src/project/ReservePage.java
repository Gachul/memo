package project;

import java.awt.event.*;

import javax.swing.*;

import net.sourceforge.jdatepicker.impl.JDatePanelImpl;
import net.sourceforge.jdatepicker.impl.JDatePickerImpl;
import net.sourceforge.jdatepicker.impl.UtilDateModel;

public class ReservePage extends JFrame implements ActionListener {

	private JFrame frame;
	private JButton confirmBtn;

	public ReservePage() {

		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("�װ��� �����ϱ� - 1");
		frame.setBounds(100, 100, 800, 600);
		frame.setResizable(false);
		frame.setLocationRelativeTo(null);
		frame.getContentPane().setLayout(null);
		frame.setVisible(true);

		JPanel reservePanel = new JPanel();
		reservePanel.setBounds(0, 0, 794, 571);
		frame.getContentPane().add(reservePanel);
		reservePanel.setLayout(null);

		JLabel lblNewLabel = new JLabel("�����");
		lblNewLabel.setBounds(38, 76, 50, 15);
		reservePanel.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("������");
		lblNewLabel_1.setBounds(428, 76, 50, 15);
		reservePanel.add(lblNewLabel_1);

		JComboBox destinationCombo = new JComboBox();
		destinationCombo.setModel(new DefaultComboBoxModel(new String[] { "�̱�", "����", "������", "��Ż����" }));
		destinationCombo.setBounds(490, 72, 213, 23);
		reservePanel.add(destinationCombo);

		JComboBox startingPointCombo = new JComboBox();
		startingPointCombo.setModel(new DefaultComboBoxModel(new String[] { "��õ����" }));
		startingPointCombo.setBounds(88, 72, 213, 23);
		reservePanel.add(startingPointCombo);

		JLabel lblNewLabel_2 = new JLabel("��߳�¥");
		lblNewLabel_2.setBounds(38, 148, 50, 15);
		reservePanel.add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("�ο�����");
		lblNewLabel_3.setBounds(88, 207, 50, 15);
		reservePanel.add(lblNewLabel_3);

		JRadioButton people1 = new JRadioButton("1");
		people1.setBounds(88, 241, 50, 23);
		reservePanel.add(people1);

		JRadioButton people2 = new JRadioButton("2");
		people2.setBounds(155, 241, 50, 23);
		reservePanel.add(people2);

		JRadioButton people3 = new JRadioButton("3");
		people3.setBounds(236, 241, 50, 23);
		reservePanel.add(people3);

		JRadioButton people4 = new JRadioButton("4");
		people4.setBounds(313, 241, 50, 23);
		reservePanel.add(people4);

		ButtonGroup peopleGroup = new ButtonGroup();
		peopleGroup.add(people1);
		peopleGroup.add(people2);
		peopleGroup.add(people3);
		peopleGroup.add(people4);

		reservePanel.add(people1);
		reservePanel.add(people2);
		reservePanel.add(people3);
		reservePanel.add(people4);

		UtilDateModel model = new UtilDateModel();
		JDatePanelImpl datePanel = new JDatePanelImpl(model);
		JDatePickerImpl departureDate = new JDatePickerImpl(datePanel);
		reservePanel.add(departureDate);
		departureDate.setBounds(88, 142, 213, 21);
		departureDate.setVisible(true);

		System.out.println(model.getYear() + "-" + (model.getMonth() + 1) + "-" + model.getDay());

		UtilDateModel model2 = new UtilDateModel();
		JDatePanelImpl datePanel2 = new JDatePanelImpl(model2);

		JLabel lblNewLabel_4 = new JLabel("������ : ");
		lblNewLabel_4.setBounds(88, 355, 50, 15);
		reservePanel.add(lblNewLabel_4);

		JLabel lblNewLabel_4_1 = new JLabel("����ϴ³�  :");
		lblNewLabel_4_1.setBounds(88, 380, 81, 15);
		reservePanel.add(lblNewLabel_4_1);

		JLabel lblNewLabel_4_1_1_1 = new JLabel("�ο��� :");
		lblNewLabel_4_1_1_1.setBounds(88, 405, 67, 15);
		reservePanel.add(lblNewLabel_4_1_1_1);

		JLabel destinationField = new JLabel("�������� �������ּ���");
		destinationField.setBounds(181, 355, 183, 15);
		reservePanel.add(destinationField);

		JLabel departureField = new JLabel("����ϴ� ���� �������ּ���");
		departureField.setBounds(181, 380, 157, 15);
		reservePanel.add(departureField);

		JLabel peopleField = new JLabel("�ο����� �������ּ���");
		peopleField.setBounds(191, 405, 146, 15);
		reservePanel.add(peopleField);

		// String[] country = {"�̱�","����","������","��Ż����"};
		ImageIcon[] images = { new ImageIcon("./img/usa.jpg"), new ImageIcon("./img/uk.jpg"),
				new ImageIcon("./img/france.jpg"), new ImageIcon("./img/italy.jpg") };

		JLabel imgLabel = new JLabel(images[0]);
		reservePanel.add(imgLabel);
		imgLabel.setBounds(428, 220, 275, 240);

		confirmBtn = new JButton("Ȯ��"); //
		confirmBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String startingPoint = startingPointCombo.getSelectedItem().toString();
				String destination = destinationField.getText();
				String departure_Date = departureField.getText();
				String arrive_Date = arriveField.getText();
				String people = peopleField.getText();

				TestDB.insertCustomer(startingPoint, destination, departure_Date, arrive_Date, people);
				JOptionPane.showMessageDialog(null, "���� �Ϸ�");
			}
		});

		confirmBtn.setBounds(464, 473, 91, 23);
		reservePanel.add(confirmBtn);

		JButton cancelBtn = new JButton("����ϱ�");
		cancelBtn.setBounds(567, 473, 91, 23);
		reservePanel.add(cancelBtn);

		JLabel lblNewLabel_4_2 = new JLabel("����� : ");
		lblNewLabel_4_2.setBounds(88, 331, 50, 15);
		reservePanel.add(lblNewLabel_4_2);

		JLabel startingPointField = new JLabel("������� �������ּ���");
		startingPointField.setBounds(180, 331, 183, 15);
		reservePanel.add(startingPointField);

		startingPointCombo.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				startingPointField.setText(startingPointCombo.getSelectedItem().toString());
			}
		});

		destinationCombo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JComboBox cb = (JComboBox) e.getSource(); // �޺��ڽ� �˾Ƴ���
				int index = cb.getSelectedIndex();// ���õ� �������� �ε���
				imgLabel.setIcon(images[index]); // �ε����� �̹����� �̹��� ���̺��� ���

				destinationField.setText(destinationCombo.getSelectedItem().toString());

			}
		});

		departureDate.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				departureField.setText(model.getYear() + "-" + (model.getMonth() + 1) + "-" + model.getDay());

			}
		});

		people1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				peopleField.setText(people1.getText());
			}
		});
		people2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				peopleField.setText(people2.getText());
			}
		});
		people3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				peopleField.setText(people3.getText());
			}
		});
		people4.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				peopleField.setText(people4.getText());
			}
		});

		confirmBtn.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == confirmBtn) {
			new FlightPage();
			frame.dispose();
		}
	}
}