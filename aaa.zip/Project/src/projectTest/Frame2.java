package projectTest;

import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JTable;
import javax.swing.ImageIcon;

public class Frame2 {
	private JFrame f;
	private JPanel p;
	private JLabel noMemLgL, telL1, telL2;
	private JButton loginBtn, backBtn, homeBtn, joinBtn, noMemJoinBtn, noMemLgBtn;
	private JTextField telF1, telF2, telF3;
	private JPasswordField pwF;
	private JLabel idL;
	private JLabel pwL;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Frame2 window = new Frame2();
					window.f.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Frame2() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		f = new JFrame();
		f.setTitle("항공권 예약 시스템 - 로그인");
		f.setBounds(100, 100, 800, 600);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.getContentPane().setLayout(null);
		f.setResizable(false);
		f.setLocationRelativeTo(null);

		p = new JPanel();
		p.setBounds(0, 0, 794, 571);
		f.getContentPane().add(p);
		p.setLayout(null);

		noMemLgL = new JLabel("NON_MEMBER LOGIN");
		noMemLgL.setFont(new Font("굴림", Font.BOLD, 38));
		noMemLgL.setBounds(113, 125, 446, 67);
		p.add(noMemLgL);

		// 아이디
		idL = new JLabel("핸드폰 번호 : ");
		idL.setFont(new Font("함초롬돋움", Font.BOLD, 18));
		idL.setBounds(124, 243, 122, 48);
		idL.setHorizontalAlignment(SwingConstants.CENTER);
		p.add(idL);
		
		telF1 = new JTextField();
		telF1.setColumns(10);
		telF1.setBounds(258, 243, 63, 48);
		p.add(telF1);
		telL1 = new JLabel("-");
		telL1.setBounds(328, 259, 17, 15);
		p.add(telL1);
		
		telF2 = new JTextField();
		telF2.setColumns(10);
		telF2.setBounds(341, 243, 63, 48);
		p.add(telF2);
		telL2 = new JLabel("-");
		telL2.setBounds(410, 259, 17, 15);
		p.add(telL2);
		
		telF3 = new JTextField();
		telF3.setColumns(10);
		telF3.setBounds(423, 243, 63, 48);
		p.add(telF3);

		// 비밀번호
		pwL = new JLabel("PW : ");
		pwL.setFont(new Font("함초롬돋움", Font.BOLD, 18));
		pwL.setBounds(183, 308, 63, 48);
		pwL.setHorizontalAlignment(SwingConstants.CENTER);
		p.add(pwL);
		pwF = new JPasswordField();
		pwF.setColumns(12);
		pwF.setBounds(258, 313, 228, 48);
		p.add(pwF);

		// 버튼
		loginBtn = new JButton("로그인");
		loginBtn.setBounds(511, 243, 122, 118);
		loginBtn.setFont(new Font("안상수2006가는", Font.BOLD, 30));
		p.add(loginBtn);

		homeBtn = new JButton("");
		homeBtn.setSelectedIcon(new ImageIcon("C:\\Users\\llsjl\\Documents\\JAVA\\WORKSPACE\\project\\image\\home.png"));
		homeBtn.setIcon(new ImageIcon("C:\\Users\\llsjl\\Documents\\JAVA\\WORKSPACE\\project\\image\\home.png"));
		homeBtn.setBounds(729, 20, 40, 40);
		p.add(homeBtn);
		
		backBtn = new JButton("<");
		backBtn.setBounds(26, 500, 41, 39);
		p.add(backBtn);

		f.setVisible(true);
	}
}
